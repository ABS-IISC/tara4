"""
Enhanced Model Configuration for AWS Bedrock Claude Models
Updated with latest Claude Sonnet 4.5 with extended thinking

Model Priority Order / Fallback Path (November 2025):
1. Claude Sonnet 4.5 (Primary) - Latest model with extended thinking
2. Claude Sonnet 4.0 (Fallback 1) - Previous generation flagship
3. Claude 3.7 Sonnet (Fallback 2) - Intermediate version
4. Claude 3.5 Sonnet June (Fallback 3) - Stable June release
5. Claude 3.5 Sonnet v2 October (Fallback 4) - Enhanced October release
6. Claude 3 Sonnet (Fallback 5) - Base Sonnet model
7. Claude 4.5 Haiku (Fallback 6) - Fast, cost-effective last resort
"""

import os
from typing import Dict, List, Any
from dataclasses import dataclass


@dataclass
class ModelConfig:
    """Configuration for a Claude model"""
    id: str
    name: str
    priority: int
    max_tokens: int
    temperature: float
    cooldown_seconds: int
    supports_extended_thinking: bool = False
    cost_per_1k_input_tokens: float = 0.0
    cost_per_1k_output_tokens: float = 0.0


class ClaudeModelRegistry:
    """
    Registry of available Claude models with their configurations

    Model IDs follow AWS Bedrock naming convention:
    anthropic.claude-{model}-{version}-v{revision}:{variant}
    """

    # Model ID constants (AWS Bedrock format)
    # Updated fallback path based on user requirements (November 2025)
    SONNET_4_5 = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"         # Priority 1
    SONNET_4_0 = "us.anthropic.claude-sonnet-4-0-20250514-v1:0"         # Priority 2
    SONNET_3_7 = "anthropic.claude-3-7-sonnet-20250219-v1:0"            # Priority 3
    SONNET_3_5_JUNE = "anthropic.claude-3-5-sonnet-20240620-v1:0"       # Priority 4 (June)
    SONNET_3_5_OCT = "anthropic.claude-3-5-sonnet-20241022-v2:0"        # Priority 5 (October v2)
    SONNET_3_0 = "anthropic.claude-3-sonnet-20240229-v1:0"              # Priority 6
    HAIKU_4_5 = "us.anthropic.claude-haiku-4-5-20250929-v1:0"           # Priority 7

    # Legacy aliases (deprecated, use specific versions above)
    SONNET_3_5 = SONNET_3_5_JUNE  # Default to June version
    SONNET_3_5_V2 = SONNET_3_5_OCT  # October version
    HAIKU_3_0 = "anthropic.claude-3-haiku-20240307-v1:0"  # Legacy Haiku 3.0

    @classmethod
    def get_production_models(cls) -> List[ModelConfig]:
        """
        Get production model configuration with priority order

        Returns:
            List of ModelConfig in priority order (1 = highest)

        Updated Fallback Path (November 2025):
        1. Claude Sonnet 4.5 (Primary)
        2. Claude Sonnet 4
        3. Claude 3.7 Sonnet
        4. Claude 3.5 Sonnet (June)
        5. Claude 3.5 Sonnet v2 (October)
        6. Claude 3 Sonnet
        7. Claude 4.5 Haiku
        """
        return [
            # Priority 1: Claude Sonnet 4.5 (Primary)
            ModelConfig(
                id=cls.SONNET_4_5,
                name="Claude Sonnet 4.5 (Extended Thinking)",
                priority=1,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=60,
                supports_extended_thinking=False,  # Disable to speed up responses
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            ),

            # Priority 2: Claude Sonnet 4.0 (Fallback 1)
            ModelConfig(
                id=cls.SONNET_4_0,
                name="Claude Sonnet 4.0",
                priority=2,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=50,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            ),

            # Priority 3: Claude 3.7 Sonnet (Fallback 2)
            ModelConfig(
                id=cls.SONNET_3_7,
                name="Claude 3.7 Sonnet",
                priority=3,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=45,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            ),

            # Priority 4: Claude 3.5 Sonnet June (Fallback 3)
            ModelConfig(
                id=cls.SONNET_3_5_JUNE,
                name="Claude 3.5 Sonnet (June)",
                priority=4,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=40,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            ),

            # Priority 5: Claude 3.5 Sonnet v2 October (Fallback 4)
            ModelConfig(
                id=cls.SONNET_3_5_OCT,
                name="Claude 3.5 Sonnet v2 (October)",
                priority=5,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=35,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            ),

            # Priority 6: Claude 3 Sonnet (Fallback 5)
            ModelConfig(
                id=cls.SONNET_3_0,
                name="Claude 3 Sonnet",
                priority=6,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=30,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            ),

            # Priority 7: Claude 4.5 Haiku (Fallback 6 - Last Resort)
            ModelConfig(
                id=cls.HAIKU_4_5,
                name="Claude 4.5 Haiku",
                priority=7,
                max_tokens=int(os.environ.get('BEDROCK_MAX_TOKENS', '4096')),
                temperature=float(os.environ.get('BEDROCK_TEMPERATURE', '0.7')),
                cooldown_seconds=20,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.00025,
                cost_per_1k_output_tokens=0.00125
            )
        ]

    @classmethod
    def get_dev_models(cls) -> List[ModelConfig]:
        """
        Get development model configuration (includes cheaper models)

        Returns:
            List of ModelConfig for development environment
        """
        return [
            # Use Haiku for development (cheaper, faster)
            ModelConfig(
                id=cls.HAIKU_3_0,
                name="Claude Haiku 3.0 (Dev)",
                priority=1,
                max_tokens=4096,
                temperature=0.7,
                cooldown_seconds=15,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.00025,
                cost_per_1k_output_tokens=0.00125
            ),

            # Fallback to Sonnet 3.5 in dev
            ModelConfig(
                id=cls.SONNET_3_5,
                name="Claude Sonnet 3.5 (Dev Fallback)",
                priority=2,
                max_tokens=4096,
                temperature=0.7,
                cooldown_seconds=30,
                supports_extended_thinking=False,
                cost_per_1k_input_tokens=0.003,
                cost_per_1k_output_tokens=0.015
            )
        ]

    @classmethod
    def get_models_for_environment(cls, environment: str = None) -> List[ModelConfig]:
        """
        Get models based on environment

        Args:
            environment: 'production', 'development', or None (auto-detect)

        Returns:
            List of ModelConfig appropriate for environment
        """
        if environment is None:
            environment = os.environ.get('ENVIRONMENT', 'production').lower()

        if environment == 'development':
            return cls.get_dev_models()
        else:
            return cls.get_production_models()

    @classmethod
    def get_model_by_id(cls, model_id: str) -> ModelConfig:
        """
        Get model configuration by ID

        Args:
            model_id: AWS Bedrock model ID

        Returns:
            ModelConfig if found, else None
        """
        all_models = cls.get_production_models() + cls.get_dev_models()
        for model in all_models:
            if model.id == model_id:
                return model
        return None

    @classmethod
    def supports_extended_thinking(cls, model_id: str) -> bool:
        """
        Check if model supports extended thinking

        Args:
            model_id: AWS Bedrock model ID

        Returns:
            True if model supports extended thinking
        """
        model = cls.get_model_by_id(model_id)
        return model.supports_extended_thinking if model else False


def build_bedrock_request_body(
    system_prompt: str,
    user_prompt: str,
    model_config: ModelConfig,
    enable_thinking: bool = None
) -> Dict[str, Any]:
    """
    Build AWS Bedrock request body with model-specific parameters

    Args:
        system_prompt: System prompt text
        user_prompt: User prompt text
        model_config: Model configuration
        enable_thinking: Enable extended thinking (None = auto-detect)

    Returns:
        Request body dict for AWS Bedrock invoke_model
    """
    # Auto-detect extended thinking if not specified
    if enable_thinking is None:
        enable_thinking = model_config.supports_extended_thinking

    # Base request body (Messages API format)
    request_body = {
        'anthropic_version': 'bedrock-2023-05-31',
        'max_tokens': model_config.max_tokens,
        'temperature': model_config.temperature,
        'system': system_prompt,
        'messages': [
            {
                'role': 'user',
                'content': user_prompt
            }
        ]
    }

    # Add extended thinking if supported and enabled
    if enable_thinking and model_config.supports_extended_thinking:
        request_body['thinking'] = {
            'type': 'enabled',
            'budget_tokens': 2000  # Reserve tokens for reasoning
        }

        # Adjust max_tokens to account for thinking budget
        request_body['max_tokens'] = model_config.max_tokens - 2000

    return request_body


def parse_bedrock_response(
    response_body: Dict[str, Any],
    model_config: ModelConfig
) -> Dict[str, Any]:
    """
    Parse AWS Bedrock response and extract thinking/content

    Args:
        response_body: Raw response from Bedrock
        model_config: Model configuration used

    Returns:
        Parsed response with thinking and content separated
    """
    content_blocks = response_body.get('content', [])

    result = {
        'thinking': None,
        'content': '',
        'model_used': model_config.name,
        'stop_reason': response_body.get('stop_reason'),
        'usage': response_body.get('usage', {})
    }

    # Extract thinking and content blocks
    for block in content_blocks:
        block_type = block.get('type')

        if block_type == 'thinking':
            # Extended thinking block (Sonnet 4.5)
            result['thinking'] = block.get('thinking', '')
        elif block_type == 'text':
            # Regular text content
            result['content'] += block.get('text', '')

    # Fallback for older format (no content blocks)
    if not result['content'] and 'completion' in response_body:
        result['content'] = response_body['completion']

    return result


# Feedback confidence threshold configuration
# Feedback items with confidence below this threshold will be filtered out
FEEDBACK_MIN_CONFIDENCE = float(os.environ.get('FEEDBACK_MIN_CONFIDENCE', '0.80'))

# Export configuration
def get_default_models() -> List[ModelConfig]:
    """Get default model configuration"""
    return ClaudeModelRegistry.get_models_for_environment()


def get_primary_model() -> ModelConfig:
    """Get primary model configuration"""
    models = get_default_models()
    return models[0] if models else None


# Example usage
if __name__ == "__main__":
    print("="*70)
    print("Claude Model Configuration")
    print("="*70)

    # Production models
    prod_models = ClaudeModelRegistry.get_production_models()
    print(f"\n📦 Production Models ({len(prod_models)}):")
    for model in prod_models:
        thinking_str = " [Extended Thinking]" if model.supports_extended_thinking else ""
        print(f"\n  {model.priority}. {model.name}{thinking_str}")
        print(f"     ID: {model.id}")
        print(f"     Max Tokens: {model.max_tokens}")
        print(f"     Temperature: {model.temperature}")
        print(f"     Cooldown: {model.cooldown_seconds}s")
        print(f"     Cost: ${model.cost_per_1k_input_tokens}/1K input, ${model.cost_per_1k_output_tokens}/1K output")

    # Development models
    dev_models = ClaudeModelRegistry.get_dev_models()
    print(f"\n📦 Development Models ({len(dev_models)}):")
    for model in dev_models:
        print(f"\n  {model.priority}. {model.name}")
        print(f"     ID: {model.id}")
        print(f"     Cost: ${model.cost_per_1k_input_tokens}/1K input (10x cheaper)")

    # Example request body
    print("\n" + "="*70)
    print("Example Request Body (with Extended Thinking)")
    print("="*70)

    primary = get_primary_model()
    request = build_bedrock_request_body(
        system_prompt="You are a helpful assistant.",
        user_prompt="Analyze this document...",
        model_config=primary,
        enable_thinking=True
    )

    import json
    print(json.dumps(request, indent=2))
