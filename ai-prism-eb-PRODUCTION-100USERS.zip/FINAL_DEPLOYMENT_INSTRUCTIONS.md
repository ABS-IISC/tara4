# FINAL ELASTIC BEANSTALK DEPLOYMENT INSTRUCTIONS

## ✅ ALL ISSUES FIXED - READY TO DEPLOY

**Deployment Package:** `ai-prism-eb-FINAL.zip` (5.5 MB)
**Date:** November 26, 2025
**Status:** All configuration errors debugged and resolved

---

## 🔧 WHAT WAS FIXED

### **Critical Bug Fix:**
**Error:** `Invalid option value: '' (Namespace: 'aws:elbv2:loadbalancer', OptionName: 'AccessLogsS3Bucket'): Value does not meet the required minimum length: 3`

**Root Cause:** Setting `AccessLogsS3Bucket: ""` (empty string) violated AWS validation rules requiring minimum 3 characters.

**Solution:** Removed ALL S3 access log configuration from `.ebextensions/01_environment.config`:
- ❌ Removed: `AccessLogsS3Enabled: "false"`
- ❌ Removed: `AccessLogsS3Bucket: ""`
- ❌ Removed: `AccessLogsS3Prefix: ""`
- ✅ Result: Load balancer uses default settings (access logs disabled by default)

---

## 📦 DEPLOYMENT STEPS

### **Step 1: Upload the New Package**

1. Go to: **Elastic Beanstalk Console** → **Applications** → **AI Prism** → **Application versions**
2. Click **"Upload"**
3. Upload: `ai-prism-eb-FINAL.zip` (from `/Users/abhsatsa/Documents/risk stuff/tool/tara2/`)
4. Version label: `ai-prism-v3-final`

### **Step 2: Create Environment (Console Wizard)**

Use the **EXACT** configuration from your last attempt:

#### **Step 1: Configure environment**
- Environment name: `AI-Prism-production`
- Platform: Python 3.11 running on 64bit Amazon Linux 2023/4.8.0
- Application code: `ai-prism-eb-FINAL.zip` ✅

#### **Step 2: Configure service access**
- Service role: `aws-elasticbeanstalk-service-role` ✅
- EC2 instance profile: `aws-elasticbeanstalk-ec2-role` ✅

#### **Step 3: Networking** (Use your existing VPC settings)
- VPC: `vpc-0ea15ff1bbb2d473e`
- Public IP: Enabled
- Instance subnets: All 3 subnets selected

#### **Step 4: Instance traffic and scaling**
- Instance type: t3.medium, t3.large
- Min instances: 1
- Max instances: 4
- Auto-scaling trigger: CPU 75% (scale up) / 25% (scale down)

#### **Step 5: Updates, monitoring, logging**
- Enhanced health monitoring: Enabled
- CloudWatch log streaming: Enabled (7 days)
- Managed updates: Enabled (Sunday 3 AM UTC)
- Notification email: `abhsatsa@amazon.com` ✅

#### **Step 6: Review and Create**
- Double-check all settings
- Click **"Create"**

---

## 🚀 EXPECTED DEPLOYMENT TIMELINE

| Time | Activity |
|------|----------|
| 0-2 min | Creating environment resources |
| 2-5 min | Creating Application Load Balancer |
| 5-10 min | Launching EC2 instances + installing dependencies |
| 10-12 min | Running health checks on `/health` endpoint |
| 12-15 min | Final configuration + DNS propagation |

**Total:** 12-15 minutes

---

## 📊 POST-DEPLOYMENT VERIFICATION

Once deployment completes (status: **Ok** - Green):

### **1. Access Your Application**
```
URL: http://ai-prism-production.[random].eu-north-1.elasticbeanstalk.com
```

### **2. Test Endpoints**
```bash
# Health check
curl http://[your-url]/health
# Expected: {"status": "healthy"}

# Main application
curl -I http://[your-url]/
# Expected: HTTP/1.1 200 OK
```

### **3. Verify Environment Variables**
Go to: **Environment** → **Configuration** → **Software** → **Environment properties**

Should show 16 variables:
- ✅ FLASK_ENV: production
- ✅ AWS_REGION: eu-north-1
- ✅ BEDROCK_MODEL_ID: anthropic.claude-sonnet-4-5-20250929-v1:0
- ✅ REDIS_URL: disabled
- ✅ S3_BUCKET_NAME: ai-prism-logs-600222957378-eu
- ✅ And 11 more...

### **4. Check CloudWatch Logs**
Go to: **Environment** → **Logs** → **Request Logs** → **Last 100 Lines**

Look for:
```
✅ Server is ready. Spawning workers
✅ Worker spawned (pid: XXXX)
✅ Booting worker with pid: XXXX
```

---

## ⚠️ IF DEPLOYMENT FAILS

### **Check Events Tab:**
1. Go to: **Environment** → **Events**
2. Look for ERROR messages (red)
3. Share the exact error message

### **Common Issues & Solutions:**

**Issue:** "Health check timeout"
- **Cause:** Application not responding on port 8000
- **Fix:** Check Gunicorn logs in CloudWatch

**Issue:** "Environment health degraded"
- **Cause:** Bedrock permissions missing
- **Fix:** Verify `aws-elasticbeanstalk-ec2-role` has `AmazonBedrockFullAccess`

**Issue:** "503 Service Unavailable"
- **Cause:** All instances failing health checks
- **Fix:** Check `/health` endpoint in application logs

---

## 📋 CONFIGURATION SUMMARY

### **Files in Deployment Package:**
- ✅ `.ebextensions/01_environment.config` (FIXED - no S3 log config)
- ✅ `.ebextensions/02_packages.config` (dependencies)
- ✅ `Procfile` (Gunicorn command)
- ✅ `gunicorn.conf.py` (5-minute timeout for Claude API)
- ✅ `app.py` (Flask application)
- ✅ `requirements.txt` (all dependencies)

### **Key Configuration Values:**
```yaml
# Load Balancer (FIXED)
aws:elbv2:loadbalancer:
  IdleTimeout: 300  # 5 minutes for long Claude API calls
  # NO AccessLogsS3Bucket configuration ✅

# Environment Variables
aws:elasticbeanstalk:application:environment:
  FLASK_ENV: production
  PORT: "8000"
  AWS_REGION: eu-north-1
  BEDROCK_MODEL_ID: anthropic.claude-sonnet-4-5-20250929-v1:0
  REDIS_URL: "disabled"
  S3_BUCKET_NAME: ai-prism-logs-600222957378-eu
  ENABLE_MODEL_FALLBACK: "true"
```

---

## ✅ PRE-FLIGHT CHECKLIST

Before clicking "Create":

- [ ] Deployment package: `ai-prism-eb-FINAL.zip` (5.5 MB) ✅
- [ ] Service role: `aws-elasticbeanstalk-service-role` ✅
- [ ] EC2 instance profile: `aws-elasticbeanstalk-ec2-role` ✅
- [ ] Region: eu-north-1 (Stockholm) ✅
- [ ] Environment name: `AI-Prism-production` ✅
- [ ] Email notification: `abhsatsa@amazon.com` ✅

---

## 🎯 SUCCESS CRITERIA

Deployment is successful when:

1. ✅ Environment status shows **"Ok"** (green health indicator)
2. ✅ All instances pass health checks (2/2 instances healthy)
3. ✅ Application URL returns HTTP 200 OK
4. ✅ `/health` endpoint returns `{"status": "healthy"}`
5. ✅ CloudWatch logs show "Server is ready"
6. ✅ Can upload a document and get AI feedback

---

## 📞 SUPPORT

If you encounter any issues during deployment:

1. Check the **Events** tab for error messages
2. Download **Full Logs** from Environment → Logs
3. Share the error details

---

**Package Location:** `/Users/abhsatsa/Documents/risk stuff/tool/tara2/ai-prism-eb-FINAL.zip`

**Ready to deploy!** 🚀
