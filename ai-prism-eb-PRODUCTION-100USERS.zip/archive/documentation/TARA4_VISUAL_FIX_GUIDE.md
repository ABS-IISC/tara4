# tara4 Visual Fix Guide - Claude 500 Error

```
┌─────────────────────────────────────────────────────────────┐
│                  YOUR APP RUNNER SERVICE                     │
│                                                              │
│  Service: tara4                                             │
│  URL: https://yymivpdgyd.us-east-1.awsapprunner.com        │
│  Status: Running ✅                                         │
│  Problem: Claude API failing ❌                            │
└─────────────────────────────────────────────────────────────┘

                           ⬇️

┌─────────────────────────────────────────────────────────────┐
│                    THE MISSING PIECE                         │
│                                                              │
│  Configuration → Security → Instance role                   │
│  Current value: (empty) ❌                                  │
│  Needed value: tara4-apprunner-role ✅                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 3-Step Visual Fix

```
┌──────────────────────────────────────────────────────────────┐
│  STEP 1: CREATE IAM POLICY (Permission Document)           │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  AWS Console → IAM → Policies → Create Policy               │
│                                                              │
│  JSON Policy:                                               │
│  ┌────────────────────────────────────────────────────┐    │
│  │ {                                                   │    │
│  │   "Statement": [                                    │    │
│  │     {                                               │    │
│  │       "Effect": "Allow",                            │    │
│  │       "Action": "bedrock:InvokeModel",              │    │
│  │       "Resource": "arn:aws:bedrock:*::claude-*"     │    │
│  │     },                                              │    │
│  │     {                                               │    │
│  │       "Effect": "Allow",                            │    │
│  │       "Action": "s3:PutObject",                     │    │
│  │       "Resource": "arn:aws:s3:::felix-s3-bucket/*"  │    │
│  │     }                                               │    │
│  │   ]                                                 │    │
│  │ }                                                   │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  Name: tara4-bedrock-s3-policy                              │
│                                                              │
│  Result: ✅ Policy created                                  │
└──────────────────────────────────────────────────────────────┘

                           ⬇️

┌──────────────────────────────────────────────────────────────┐
│  STEP 2: CREATE IAM ROLE (Identity Card)                   │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  AWS Console → IAM → Roles → Create Role                    │
│                                                              │
│  Trusted Entity: AWS service → App Runner                   │
│                                                              │
│  Attach Policy: tara4-bedrock-s3-policy ✅                  │
│                                                              │
│  Role Name: tara4-apprunner-role                            │
│                                                              │
│  Result: ✅ Role created                                     │
│  ARN: arn:aws:iam::758897368787:role/tara4-apprunner-role  │
└──────────────────────────────────────────────────────────────┘

                           ⬇️

┌──────────────────────────────────────────────────────────────┐
│  STEP 3: ATTACH ROLE TO tara4                              │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  App Runner → tara4 → Configuration → Security → Edit       │
│                                                              │
│  Before:                                                    │
│  ┌────────────────────────────────────────────────────┐    │
│  │ Instance role: (none) ❌                           │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  After:                                                     │
│  ┌────────────────────────────────────────────────────┐    │
│  │ Instance role: tara4-apprunner-role ✅             │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  Click: Save changes                                        │
│                                                              │
│  Result: ⏳ Update in progress...                           │
└──────────────────────────────────────────────────────────────┘

                           ⬇️

┌──────────────────────────────────────────────────────────────┐
│  STEP 4: WAIT FOR REDEPLOYMENT (5-10 minutes)              │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  Status Timeline:                                           │
│                                                              │
│  Minute 0:  ⏳ Update in progress                           │
│  Minute 2:  ⏳ Deploying...                                 │
│  Minute 5:  ⏳ Still deploying...                           │
│  Minute 8:  ✅ Running                                      │
│                                                              │
│  ⚠️  DO NOT TEST UNTIL STATUS = "Running"                  │
└──────────────────────────────────────────────────────────────┘

                           ⬇️

┌──────────────────────────────────────────────────────────────┐
│  STEP 5: TEST YOUR APP                                     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  1. Open: https://yymivpdgyd.us-east-1.awsapprunner.com    │
│     Result: ✅ Page loads                                   │
│                                                              │
│  2. Upload Word document                                    │
│     Result: ✅ Upload successful                            │
│                                                              │
│  3. Click "Analyze" on any section                          │
│     Result: ✅ Loading spinner appears                      │
│             ✅ Feedback items appear                        │
│             ✅ NO 500 error!                                │
│                                                              │
│  4. Accept/Reject feedback                                  │
│     Result: ✅ Buttons work                                 │
│                                                              │
│  5. Click "Submit All Feedbacks"                            │
│     Result: ✅ Document created                             │
│                                                              │
│  6. Click "Download Document"                               │
│     Result: ✅ File downloads with comments                 │
│                                                              │
│  SUCCESS! 🎉                                                │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔄 How It Works (Visual)

### BEFORE FIX:
```
┌─────────┐         ┌──────────┐         ┌──────────┐
│  User   │────────▶│  tara4   │────────▶│ Bedrock  │
│         │  Upload │          │ Call AI │ (Claude) │
└─────────┘         └──────────┘         └──────────┘
                         │                     │
                         │                     │
                         │   ❌ Who are you?   │
                         │◀────────────────────│
                         │   No credentials    │
                         │                     │
                         ▼
                    ❌ 500 ERROR
                    No permission
```

### AFTER FIX:
```
┌─────────┐         ┌──────────┐         ┌──────────┐
│  User   │────────▶│  tara4   │────────▶│ Bedrock  │
│         │  Upload │   with   │ Call AI │ (Claude) │
└─────────┘         │   Role   │         └──────────┘
                    └──────────┘              │
                         │                    │
                         │   ✅ I'm tara4    │
                         │   Role:XXX         │
                         │◀───────────────────│
                         │   ✅ Approved!     │
                         │                    │
                         ▼
                    ✅ SUCCESS
                    Feedback returned
```

---

## 📊 What Your Configuration Shows

### Current Environment Variables (✅ CORRECT):
```
┌──────────────────────────────────────────────────┐
│ AWS_REGION           = us-east-1          ✅    │
│ AWS_DEFAULT_REGION   = us-east-1          ✅    │
│ BEDROCK_MODEL_ID     = claude-3-5-sonnet   ✅    │
│ BEDROCK_MAX_TOKENS   = 8192               ✅    │
│ BEDROCK_TEMPERATURE  = 0.7                ✅    │
│ S3_BUCKET_NAME       = felix-s3-bucket     ✅    │
│ S3_BASE_PATH         = tara/              ✅    │
│ FLASK_ENV            = production         ✅    │
│ PORT                 = 8080               ✅    │
└──────────────────────────────────────────────────┘
```

### Missing Security Configuration (❌ NEEDS FIX):
```
┌──────────────────────────────────────────────────┐
│ Instance role        = (empty)             ❌    │
│                                                   │
│ Should be:                                       │
│ Instance role        = tara4-apprunner-role ✅  │
└──────────────────────────────────────────────────┘
```

---

## 🎯 Verification Checklist

```
┌─────────────────────────────────────────────────────────┐
│  AFTER COMPLETING ALL STEPS, VERIFY:                   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ✅ IAM Policy exists:                                  │
│     Name: tara4-bedrock-s3-policy                       │
│     Permissions: bedrock:InvokeModel, s3:PutObject      │
│                                                          │
│  ✅ IAM Role exists:                                    │
│     Name: tara4-apprunner-role                          │
│     Policy attached: tara4-bedrock-s3-policy            │
│     Trusted entity: App Runner                          │
│                                                          │
│  ✅ Role attached to tara4:                             │
│     Configuration → Security → Instance role shows:     │
│     tara4-apprunner-role                                │
│                                                          │
│  ✅ Redeployment complete:                              │
│     Status: Running (green)                             │
│     No "Update in progress" message                     │
│                                                          │
│  ✅ App works:                                          │
│     Can upload documents                                │
│     Can analyze with AI                                 │
│     No 500 errors                                       │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## ⏱️ Time Estimate

```
┌──────────────────────────────────────────┐
│  Step 1: Create Policy      │  2 min    │
│  Step 2: Create Role         │  3 min    │
│  Step 3: Attach Role         │  2 min    │
│  ─────────────────────────────────────── │
│  Your work:                  │  7 min    │
│                                           │
│  Step 4: Wait for deploy     │ 5-10 min  │
│  ─────────────────────────────────────── │
│  Total time:                 │ 12-17 min │
└──────────────────────────────────────────┘
```

---

## 🆘 Common Mistakes

```
┌─────────────────────────────────────────────────────────────┐
│  MISTAKE #1: Not waiting long enough                        │
│  ─────────────────────────────────────────────────────────  │
│  ❌ Tested immediately after clicking Save                  │
│  ✅ Wait until status returns to "Running"                  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  MISTAKE #2: Role not actually attached                     │
│  ─────────────────────────────────────────────────────────  │
│  ❌ Clicked Save but dropdown was empty                     │
│  ✅ Verify role name appears in dropdown before Save        │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  MISTAKE #3: Policy not attached to role                    │
│  ─────────────────────────────────────────────────────────  │
│  ❌ Created role but forgot to attach policy                │
│  ✅ Check: IAM → Roles → tara4-apprunner-role → Permissions │
│     Should show: tara4-bedrock-s3-policy                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 📞 Get Help

If still not working after following ALL steps:

**Send me:**
1. Screenshot of: App Runner → tara4 → Configuration → Security
2. Screenshot of: IAM → Roles → tara4-apprunner-role → Permissions tab
3. Logs: App Runner → tara4 → Logs → Application logs (last 50 lines)
4. Tell me: Did you see "Update in progress"? How long did you wait?

---

## 🎉 Success Looks Like This

```
┌──────────────────────────────────────────────────────────┐
│  https://yymivpdgyd.us-east-1.awsapprunner.com          │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  📄 AI-PRISM Document Analysis                           │
│                                                           │
│  [Upload Document] ✅                                    │
│                                                           │
│  Section: Introduction                                   │
│  [Analyze] ← Click this                                  │
│                                                           │
│  ↓ After clicking Analyze:                               │
│                                                           │
│  🤖 AI-Generated Feedback                                │
│  ┌────────────────────────────────────────────────┐     │
│  │ ✅ Suggestion: Add more detail about...       │     │
│  │    [Accept] [Reject]                           │     │
│  │                                                │     │
│  │ ⚠️  Critical: Missing key information...      │     │
│  │    [Accept] [Reject]                           │     │
│  │                                                │     │
│  │ ❓ Question: Can you clarify...               │     │
│  │    [Accept] [Reject]                           │     │
│  └────────────────────────────────────────────────┘     │
│                                                           │
│  ✅ NO 500 ERRORS!                                       │
│  ✅ Claude is working!                                   │
│  ✅ App is functional!                                   │
└──────────────────────────────────────────────────────────┘
```

---

**THE ONLY THING WRONG IS THE MISSING INSTANCE ROLE. FIX THAT AND EVERYTHING WORKS!**

---

**Created:** November 17, 2025
**Service:** tara4
**Issue:** Missing IAM Instance Role
**Time to fix:** 7 minutes of work + 10 minutes waiting
