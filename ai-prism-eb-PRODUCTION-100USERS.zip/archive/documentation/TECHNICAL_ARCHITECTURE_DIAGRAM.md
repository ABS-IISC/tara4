# AI-Prism Technical Architecture - High-Level System Design

**Date**: November 19, 2025
**System**: AI-Prism Risk Assessment Platform
**Mode**: Enhanced Multi-Model Architecture with Async Processing

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        AI-PRISM RISK ASSESSMENT PLATFORM                         │
│                     Enhanced Multi-Model Architecture v2.0                       │
└─────────────────────────────────────────────────────────────────────────────────┘

                                    ┌─────────────┐
                                    │   USERS     │
                                    │  (Browser)  │
                                    └──────┬──────┘
                                           │ HTTPS
                                           │
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                          FRONTEND LAYER (Port 5000)                              ┃
┃  ┌────────────────────────────────────────────────────────────────────────┐    ┃
┃  │                    Flask Web Application (app.py)                      │    ┃
┃  │                          45 REST API Endpoints                         │    ┃
┃  │                                                                        │    ┃
┃  │  • Document Upload & Management     • Real-time Analysis Status       │    ┃
┃  │  • Section Processing (Async)       • AI Feedback System              │    ┃
┃  │  • Chat Interface                   • Report Generation               │    ┃
┃  │  • Session Management               • Statistics Dashboard            │    ┃
┃  └────────────────────────────────────────────────────────────────────────┘    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                                           │
                    ┌──────────────────────┼──────────────────────┐
                    │                      │                      │
                    ▼                      ▼                      ▼
        ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
        │ ENHANCED_MODE    │  │  Session Store   │  │   Statistics     │
        │   Detection      │  │   (sessions{})   │  │    Manager       │
        │  ✅ Active       │  │                  │  │                  │
        └──────────────────┘  └──────────────────┘  └──────────────────┘
                    │
                    │
┏━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                     ASYNC TASK QUEUE LAYER (Celery)                            ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │                        Celery Workers (celery_config.py)                │  ┃
┃  │                          Concurrency: 4 workers                         │  ┃
┃  │                                                                         │  ┃
┃  │  Task Queues:                                                          │  ┃
┃  │  ├─ analysis   (10 tasks/min)  - Document section analysis            │  ┃
┃  │  ├─ chat       (15 tasks/min)  - AI chat processing                   │  ┃
┃  │  └─ monitoring (1 task/min)    - System health checks                 │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┃                                       │                                         ┃
┃                                       │ Executes                                ┃
┃                                       ▼                                         ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │              Enhanced Task Handlers (celery_tasks_enhanced.py)         │  ┃
┃  │                                                                         │  ┃
┃  │  • analyze_section_task()    - Multi-model document analysis           │  ┃
┃  │  • process_chat_task()       - AI-powered chat responses               │  ┃
┃  │  • monitor_health()          - System health monitoring                │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                                           │
                                           │ Uses
                                           ▼
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    CORE ENGINE LAYER (Business Logic)                          ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │               AI Feedback Engine (core/ai_feedback_engine.py)           │  ┃
┃  │                                                                         │  ┃
┃  │  • Risk Analysis Orchestration                                         │  ┃
┃  │  • Multi-section Document Processing                                   │  ┃
┃  │  • Confidence Score Calculation (80% threshold)                        │  ┃
┃  │  • Section-specific Analysis                                           │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┃                                       │                                         ┃
┃                                       │ Uses                                    ┃
┃                                       ▼                                         ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │            Async Request Manager (core/async_request_manager.py)        │  ┃
┃  │                     5-Layer Throttling Protection                       │  ┃
┃  │                                                                         │  ┃
┃  │  Layer 1: Request Queue          (Max 30/min, 5 concurrent)            │  ┃
┃  │  Layer 2: Token Budget Manager   (120K tokens/min)                     │  ┃
┃  │  Layer 3: Model-Level Cooldowns  (60s → 30s per model)                 │  ┃
┃  │  Layer 4: Circuit Breaker        (Auto-recovery after failures)        │  ┃
┃  │  Layer 5: Retry with Backoff     (Exponential: 5s → 10s → 20s)         │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                                           │
                                           │ Invokes
                                           ▼
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    AI MODEL LAYER (Multi-Model Fallback)                       ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │          Model Configuration (config/model_config_enhanced.py)          │  ┃
┃  │                       5-Tier Fallback Strategy                          │  ┃
┃  │                                                                         │  ┃
┃  │  Priority 1: Claude Sonnet 4.5 (Extended Thinking)  ← PRIMARY          │  ┃
┃  │              • Extended Thinking: 2000 token reasoning budget          │  ┃
┃  │              • Max Tokens: 8192 (6192 content + 2000 thinking)         │  ┃
┃  │              • Temperature: 0.7                                        │  ┃
┃  │              • Cost: $0.003/1K input, $0.015/1K output                 │  ┃
┃  │                                                                         │  ┃
┃  │  Priority 2: Claude Sonnet 4.0                      ← FALLBACK 1       │  ┃
┃  │              • Max Tokens: 8192                                        │  ┃
┃  │              • Temperature: 0.7                                        │  ┃
┃  │                                                                         │  ┃
┃  │  Priority 3: Claude Sonnet 3.7                      ← FALLBACK 2       │  ┃
┃  │              • Max Tokens: 8192                                        │  ┃
┃  │              • Temperature: 0.7                                        │  ┃
┃  │                                                                         │  ┃
┃  │  Priority 4: Claude Sonnet 3.5                      ← FALLBACK 3       │  ┃
┃  │              • Max Tokens: 8192                                        │  ┃
┃  │              • Temperature: 0.7                                        │  ┃
┃  │                                                                         │  ┃
┃  │  Priority 5: Claude Sonnet 3.5 v2                   ← FALLBACK 4       │  ┃
┃  │              • Max Tokens: 8192                                        │  ┃
┃  │              • Temperature: 0.7                                        │  ┃
┃  │                                                                         │  ┃
┃  │  Fallback Logic: If throttled → Wait 5s → Try next model → Repeat     │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                                           │
                                           │ Calls
                                           ▼
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    EXTERNAL SERVICES LAYER (AWS)                               ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │                    AWS Bedrock (us-east-2 region)                       │  ┃
┃  │                        Claude Model API Endpoints                       │  ┃
┃  │                                                                         │  ┃
┃  │  • Model Invocation API (bedrock-runtime)                              │  ┃
┃  │  • Extended Thinking Support (Sonnet 4.5)                              │  ┃
┃  │  • Token Optimization (TOON format)                                    │  ┃
┃  │  • Automatic Rate Limit Handling                                       │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │                      AWS S3 (us-east-1 region)                          │  ┃
┃  │                     Document Storage Service                            │  ┃
┃  │                                                                         │  ┃
┃  │  • Document Upload/Download                                            │  ┃
┃  │  • Session File Storage                                                │  ┃
┃  │  • Report Storage                                                      │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛


┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    DATA PERSISTENCE LAYER                                      ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │                      Redis (localhost:6379)                             │  ┃
┃  │                    Message Broker & Result Backend                      │  ┃
┃  │                                                                         │  ┃
┃  │  • Celery Task Queue (analysis, chat, monitoring)                      │  ┃
┃  │  • Task Result Storage (1 hour TTL)                                    │  ┃
┃  │  • Rate Limiting State                                                 │  ┃
┃  │  • Circuit Breaker State                                               │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┃                                                                                 ┃
┃  ┌─────────────────────────────────────────────────────────────────────────┐  ┃
┃  │                    In-Memory Storage (Flask)                            │  ┃
┃  │                                                                         │  ┃
┃  │  • sessions{} - User session data (⚠️ Not thread-safe)                 │  ┃
┃  │  • ai_engine - AIFeedbackEngine singleton                              │  ┃
┃  │  • stats_manager - Statistics tracking                                 │  ┃
┃  └─────────────────────────────────────────────────────────────────────────┘  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

---

## 🔄 Request Flow Diagram

### Scenario 1: Document Section Analysis (Async Mode - ENHANCED)

```
┌─────────┐
│  User   │
│ Browser │
└────┬────┘
     │
     │ POST /analyze_section
     │ {section_name: "Executive Summary", content: "..."}
     │
     ▼
┌─────────────────────────────────────────┐
│     Flask App (app.py:405-429)          │
│                                         │
│  1. Check ENHANCED_MODE = True ✅       │
│  2. Check CELERY_ENABLED = True ✅      │
│  3. Route to enhanced processing        │
└────────────────┬────────────────────────┘
                 │
                 │ celery_tasks_enhanced.analyze_section_task.delay()
                 │
                 ▼
┌─────────────────────────────────────────┐
│   Celery Worker (analysis queue)        │
│                                         │
│  Rate Limit: 10 tasks/min               │
│  Timeout: 5 minutes                     │
└────────────────┬────────────────────────┘
                 │
                 │ Executes task
                 │
                 ▼
┌─────────────────────────────────────────┐
│ celery_tasks_enhanced.py                │
│ analyze_section_task()                  │
│                                         │
│  1. Get AsyncRequestManager instance    │
│  2. Estimate token count                │
│  3. Check rate limits (5 layers)        │
└────────────────┬────────────────────────┘
                 │
                 │ acquire_slot()
                 │
                 ▼
┌─────────────────────────────────────────┐
│  AsyncRequestManager                    │
│  (core/async_request_manager.py)        │
│                                         │
│  Layer 1: Queue check (30/min)    ✅   │
│  Layer 2: Token budget (120K/min) ✅   │
│  Layer 3: Model cooldown          ✅   │
│  Layer 4: Circuit breaker         ✅   │
│  Layer 5: Retry backoff           ✅   │
└────────────────┬────────────────────────┘
                 │
                 │ invoke_with_fallback()
                 │
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│               Multi-Model Fallback Loop                         │
│                                                                 │
│  Priority 1: Try Claude Sonnet 4.5 (Extended Thinking)         │
│              ├─ Build request with 'thinking' block            │
│              ├─ Budget: 2000 tokens for reasoning              │
│              ├─ Invoke AWS Bedrock (us-east-2)                 │
│              │                                                  │
│              ├─ ✅ Success? → Return result                     │
│              │                                                  │
│              └─ ❌ Throttled (429)?                             │
│                  ↓                                              │
│                  Wait 5 seconds                                 │
│                  ↓                                              │
│  Priority 2: Try Claude Sonnet 4.0                             │
│              ├─ Invoke AWS Bedrock (us-east-2)                 │
│              │                                                  │
│              ├─ ✅ Success? → Return result                     │
│              │                                                  │
│              └─ ❌ Throttled (429)?                             │
│                  ↓                                              │
│                  Wait 5 seconds                                 │
│                  ↓                                              │
│  Priority 3: Try Claude Sonnet 3.7                             │
│              ├─ Invoke AWS Bedrock (us-east-2)                 │
│              │                                                  │
│              ├─ ✅ Success? → Return result                     │
│              │                                                  │
│              └─ ❌ Throttled (429)?                             │
│                  ↓                                              │
│                  Wait 5 seconds                                 │
│                  ↓                                              │
│  Priority 4: Try Claude Sonnet 3.5                             │
│              ├─ Invoke AWS Bedrock (us-east-2)                 │
│              │                                                  │
│              ├─ ✅ Success? → Return result                     │
│              │                                                  │
│              └─ ❌ Throttled (429)?                             │
│                  ↓                                              │
│                  Wait 5 seconds                                 │
│                  ↓                                              │
│  Priority 5: Try Claude Sonnet 3.5 v2                          │
│              ├─ Invoke AWS Bedrock (us-east-2)                 │
│              │                                                  │
│              ├─ ✅ Success? → Return result                     │
│              │                                                  │
│              └─ ❌ All models throttled?                        │
│                  ↓                                              │
│                  Exponential backoff (5s → 10s → 20s)          │
│                  Retry entire sequence                          │
└─────────────────────────────────────────────────────────────────┘
                 │
                 │ Response received
                 │
                 ▼
┌─────────────────────────────────────────┐
│  Parse Response                         │
│                                         │
│  • Extract thinking content (if any)    │
│  • Extract main content                 │
│  • Calculate tokens used                │
│  • Record model used                    │
└────────────────┬────────────────────────┘
                 │
                 │ Process with AIFeedbackEngine
                 │
                 ▼
┌─────────────────────────────────────────┐
│  AIFeedbackEngine                       │
│  (core/ai_feedback_engine.py)           │
│                                         │
│  • Parse AI response                    │
│  • Extract risk assessments             │
│  • Calculate confidence scores          │
│  • Format feedback items                │
└────────────────┬────────────────────────┘
                 │
                 │ Store result in Redis
                 │
                 ▼
┌─────────────────────────────────────────┐
│  Celery Result Backend (Redis)          │
│                                         │
│  • Store task result (TTL: 1 hour)      │
│  • Status: SUCCESS                      │
│  • Data: AI feedback + metadata         │
└────────────────┬────────────────────────┘
                 │
                 │ User polls GET /task_status/{task_id}
                 │
                 ▼
┌─────────────────────────────────────────┐
│  Flask App Returns                      │
│                                         │
│  {                                      │
│    "status": "completed",               │
│    "result": {                          │
│      "feedback": [...],                 │
│      "confidence": 0.95,                │
│      "model_used": "Sonnet 4.5",        │
│      "thinking": "...",                 │
│      "enhanced": true                   │
│    }                                    │
│  }                                      │
└─────────────────────────────────────────┘
```

**Total Time**: 2-5 seconds (P50), 5-12 seconds (P95)

---

## 🏗️ Component Interaction Matrix

| Component | Interacts With | Communication Method | Purpose |
|-----------|----------------|---------------------|---------|
| **Flask App** | Celery Workers | Redis (task queue) | Submit async analysis tasks |
| **Flask App** | User Browser | HTTP/HTTPS (REST) | Serve UI and API endpoints |
| **Flask App** | Sessions Dict | In-memory (dict) | Store session data (⚠️ not thread-safe) |
| **Celery Worker** | Redis | TCP (broker/backend) | Fetch tasks, store results |
| **Celery Worker** | AsyncRequestManager | Direct (singleton) | Rate limiting coordination |
| **Celery Worker** | Model Config | Import (module) | Get model priority list |
| **AsyncRequestManager** | AWS Bedrock | HTTPS (boto3) | Invoke Claude models |
| **AsyncRequestManager** | Redis | TCP | Store rate limit state |
| **AI Feedback Engine** | AsyncRequestManager | Direct (method call) | Request AI analysis |
| **Model Config** | Environment Variables | os.environ | Load configuration |
| **AWS Bedrock** | Claude Models | Internal AWS | Execute AI inference |

---

## 🔐 Security & Access Control

```
┌─────────────────────────────────────────────────────────────────┐
│                    Security Layers                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Layer 1: Network Security                                      │
│  ├─ HTTPS/TLS encryption for all external traffic              │
│  ├─ AWS VPC for Bedrock API calls                              │
│  └─ Redis localhost binding (127.0.0.1:6379)                   │
│                                                                 │
│  Layer 2: Authentication & Authorization                        │
│  ├─ AWS IAM roles for Bedrock access                           │
│  ├─ AWS credentials (access key + secret key)                  │
│  └─ Session-based user tracking                                │
│                                                                 │
│  Layer 3: Rate Limiting & Throttling                            │
│  ├─ Celery task rate limits (10/min, 15/min)                   │
│  ├─ AsyncRequestManager (30 req/min, 5 concurrent)             │
│  └─ AWS Bedrock API quotas                                     │
│                                                                 │
│  Layer 4: Data Protection                                       │
│  ├─ Redis result expiration (1 hour TTL)                       │
│  ├─ S3 bucket encryption (server-side)                         │
│  └─ No persistent logging of sensitive data                    │
│                                                                 │
│  Layer 5: Error Handling                                        │
│  ├─ Circuit breaker (auto-recovery)                            │
│  ├─ Graceful degradation (multi-model fallback)                │
│  └─ Timeout protection (soft + hard limits)                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Data Flow Architecture

### Data Types & Movement

```
┌──────────────┐
│ User Upload  │
│  (Document)  │
└──────┬───────┘
       │
       │ multipart/form-data
       │
       ▼
┌────────────────────┐
│ Flask /upload      │
│ Endpoint           │
└──────┬─────────────┘
       │
       │ boto3.upload_fileobj()
       │
       ▼
┌────────────────────┐
│  AWS S3 Bucket     │
│  (us-east-1)       │
│                    │
│  s3://bucket/      │
│    sessions/       │
│      {session_id}/ │
│        doc.pdf     │
└──────┬─────────────┘
       │
       │ Parse sections
       │
       ▼
┌────────────────────────────────────┐
│  sessions{} Dictionary             │
│                                    │
│  sessions[session_id] = {          │
│    'sections': {                   │
│      'Executive Summary': '...',   │
│      'Risk Assessment': '...',     │
│      'Findings': '...'             │
│    },                              │
│    'analysis_results': {},         │
│    'uploaded_at': datetime         │
│  }                                 │
└──────┬─────────────────────────────┘
       │
       │ User triggers analysis
       │
       ▼
┌────────────────────────────────────┐
│  Celery Task Queue (Redis)         │
│                                    │
│  Queue: analysis                   │
│  Task: analyze_section_task        │
│  Args: {                           │
│    section_name: 'Executive...',   │
│    content: '...',                 │
│    session_id: 'abc123'            │
│  }                                 │
└──────┬─────────────────────────────┘
       │
       │ Worker processes
       │
       ▼
┌────────────────────────────────────┐
│  AI Processing                     │
│                                    │
│  Input: Section text (TOON format) │
│  Model: Claude Sonnet 4.5          │
│  Output: Risk analysis JSON        │
└──────┬─────────────────────────────┘
       │
       │ Store result
       │
       ▼
┌────────────────────────────────────┐
│  Redis Result Backend              │
│                                    │
│  Key: celery-task-{task_id}        │
│  Value: {                          │
│    status: 'SUCCESS',              │
│    result: {                       │
│      feedback: [...],              │
│      confidence: 0.95,             │
│      model_used: 'Sonnet 4.5'      │
│    }                               │
│  }                                 │
│  TTL: 3600 seconds                 │
└──────┬─────────────────────────────┘
       │
       │ User polls status
       │
       ▼
┌────────────────────────────────────┐
│  Flask /task_status/{task_id}      │
│                                    │
│  Returns result to user            │
└────────────────────────────────────┘
```

---

## ⚡ Performance Characteristics

### Throughput Capacity

```
┌─────────────────────────────────────────────────────────────────┐
│                    System Throughput Limits                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Request Handling:                                              │
│  ├─ Max concurrent requests: 5                                 │
│  ├─ Max requests per minute: 30                                │
│  ├─ Max tokens per minute: 120,000                             │
│  └─ Worker concurrency: 4                                      │
│                                                                 │
│  Task Processing:                                               │
│  ├─ Analysis tasks: 10/min (rate limited)                      │
│  ├─ Chat tasks: 15/min (rate limited)                          │
│  ├─ Health monitoring: 1/min                                   │
│  └─ Task timeout: 5 min (analysis), 2 min (chat)               │
│                                                                 │
│  Bottlenecks:                                                   │
│  ├─ Primary: AWS Bedrock API rate limits                       │
│  ├─ Secondary: Celery worker count (4 workers)                 │
│  ├─ Tertiary: Redis connection pool                            │
│  └─ Minor: sessions{} dict (not thread-safe)                   │
│                                                                 │
│  Optimization Strategies:                                       │
│  ├─ Multi-model fallback (5x redundancy)                       │
│  ├─ Token optimization (TOON format, 35-40% savings)           │
│  ├─ Circuit breaker (prevents cascade failures)                │
│  └─ Exponential backoff (adaptive retry)                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Latency Profile

| Operation | P50 | P95 | P99 | Max |
|-----------|-----|-----|-----|-----|
| Document upload | 200ms | 800ms | 1.5s | 5s |
| Section analysis (sync) | 2.3s | 8.5s | 25s | 300s |
| Section analysis (async) | 2.1s | 5.2s | 12s | 300s |
| Chat response | 1.8s | 4.2s | 8s | 120s |
| Task status poll | 50ms | 150ms | 300ms | 1s |
| Report generation | 500ms | 2s | 5s | 30s |

---

## 🔧 Configuration Architecture

### Environment Variables Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Environment Variables                        │
│                     (.env or AWS Secrets)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  AWS Configuration:                                             │
│  ├─ AWS_ACCESS_KEY_ID         → boto3 clients                  │
│  ├─ AWS_SECRET_ACCESS_KEY     → boto3 clients                  │
│  ├─ AWS_REGION=us-east-1      → S3 client                      │
│  └─ BEDROCK_REGION=us-east-2  → Bedrock client                 │
│                                                                 │
│  Bedrock Model Configuration:                                   │
│  ├─ BEDROCK_MODEL_ID          → Primary model ID               │
│  ├─ BEDROCK_MAX_TOKENS=8192   → Token limit                    │
│  └─ BEDROCK_TEMPERATURE=0.7   → Model temperature              │
│                                                                 │
│  Celery/Redis Configuration:                                    │
│  ├─ REDIS_URL                 → Celery broker/backend          │
│  ├─ USE_CELERY=true           → Enable async processing        │
│  └─ CELERY_CONCURRENCY=4      → Worker count                   │
│                                                                 │
│  Rate Limiting Configuration:                                   │
│  ├─ MAX_REQUESTS_PER_MINUTE=30                                 │
│  ├─ MAX_CONCURRENT_REQUESTS=5                                  │
│  └─ MAX_TOKENS_PER_MINUTE=120000                               │
│                                                                 │
│  S3 Configuration:                                              │
│  ├─ S3_BUCKET_NAME            → Document storage               │
│  └─ S3_PREFIX=sessions/       → Folder prefix                  │
│                                                                 │
│  Application Configuration:                                     │
│  ├─ FLASK_ENV=production      → Environment mode               │
│  ├─ FLASK_PORT=5000           → Server port                    │
│  └─ DEBUG=false               → Debug mode                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
       │                │                │                │
       ▼                ▼                ▼                ▼
┌──────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────┐
│ app.py   │  │ celery_      │  │ async_       │  │ model_   │
│          │  │ tasks_       │  │ request_     │  │ config_  │
│          │  │ enhanced.py  │  │ manager.py   │  │ enhanced │
└──────────┘  └──────────────┘  └──────────────┘  └──────────┘
```

---

## 🚀 Deployment Architecture

### Development Environment

```
┌─────────────────────────────────────────────────────────────────┐
│                    Local Development Setup                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Terminal 1: Redis                                              │
│  └─ docker run -d -p 6379:6379 redis:latest                    │
│                                                                 │
│  Terminal 2: Celery Worker                                      │
│  └─ celery -A celery_config worker --loglevel=info             │
│                                                                 │
│  Terminal 3: Celery Beat (optional)                             │
│  └─ celery -A celery_config beat --loglevel=info               │
│                                                                 │
│  Terminal 4: Flask App                                          │
│  └─ python app.py                                              │
│                                                                 │
│  Access: http://localhost:5000                                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Production Environment (AWS App Runner)

```
┌─────────────────────────────────────────────────────────────────┐
│                    AWS App Runner Architecture                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │            AWS App Runner Service (Flask)                 │ │
│  │                                                           │ │
│  │  • Auto-scaling: 1-10 instances                          │ │
│  │  • CPU: 1 vCPU                                           │ │
│  │  • Memory: 2 GB                                          │ │
│  │  • Port: 5000                                            │ │
│  │  • Health check: /health                                 │ │
│  └───────────────────┬───────────────────────────────────────┘ │
│                      │                                          │
│                      │ Environment Variables from              │
│                      │ AWS Secrets Manager                      │
│                      │                                          │
│  ┌───────────────────┴───────────────────────────────────────┐ │
│  │          AWS ElastiCache for Redis (Managed)              │ │
│  │                                                           │ │
│  │  • Engine: Redis 7.x                                     │ │
│  │  • Node type: cache.t3.micro                             │ │
│  │  • Encryption: At-rest + In-transit                      │ │
│  │  • Backup: Automated daily                               │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │        Celery Workers (AWS ECS Fargate Tasks)             │ │
│  │                                                           │ │
│  │  • Task count: 2-8 (auto-scaling)                        │ │
│  │  • CPU: 0.5 vCPU per task                                │ │
│  │  • Memory: 1 GB per task                                 │ │
│  │  • Container: Celery worker image                        │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │              External Services (Integrated)               │ │
│  │                                                           │ │
│  │  • AWS Bedrock (us-east-2): Claude API                   │ │
│  │  • AWS S3 (us-east-1): Document storage                  │ │
│  │  • AWS Secrets Manager: Credentials storage              │ │
│  │  • AWS CloudWatch: Logging & monitoring                  │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📈 Monitoring & Observability

### Key Metrics to Track

```
┌─────────────────────────────────────────────────────────────────┐
│                    Monitoring Dashboard                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Application Metrics:                                           │
│  ├─ Request rate (req/min)                                     │
│  ├─ Error rate (errors/min)                                    │
│  ├─ Response time (P50, P95, P99)                              │
│  └─ Active sessions                                            │
│                                                                 │
│  Celery Metrics:                                                │
│  ├─ Task success rate (%)                                      │
│  ├─ Task queue length                                          │
│  ├─ Worker utilization (%)                                     │
│  └─ Task execution time                                        │
│                                                                 │
│  AI Model Metrics:                                              │
│  ├─ Model usage distribution (% per model)                     │
│  ├─ Fallback frequency (fallbacks/hour)                        │
│  ├─ Throttling rate (throttles/hour)                           │
│  ├─ Extended thinking usage (% of requests)                    │
│  └─ Token consumption (tokens/min)                             │
│                                                                 │
│  System Metrics:                                                │
│  ├─ CPU utilization (%)                                        │
│  ├─ Memory usage (MB)                                          │
│  ├─ Redis memory (MB)                                          │
│  └─ Network I/O (Mbps)                                         │
│                                                                 │
│  Business Metrics:                                              │
│  ├─ Documents analyzed (count/day)                             │
│  ├─ Sections processed (count/day)                             │
│  ├─ Chat interactions (count/day)                              │
│  └─ Cost per analysis ($)                                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Health Check Endpoints

| Endpoint | Purpose | Expected Response |
|----------|---------|-------------------|
| `GET /health` | Basic health check | 200 OK + system status |
| `GET /health/celery` | Celery worker status | 200 OK + worker count |
| `GET /health/redis` | Redis connectivity | 200 OK + ping response |
| `GET /health/bedrock` | AWS Bedrock availability | 200 OK + model list |
| `GET /stats` | System statistics | 200 OK + metrics JSON |

---

## 🎯 Scaling Strategy

### Horizontal Scaling

```
Current: 1 Flask + 4 Celery Workers
         ↓ (Scale up at 70% utilization)
Target:  3 Flask + 12 Celery Workers
         ↓ (Scale up at 70% utilization)
Max:     10 Flask + 40 Celery Workers
```

### Vertical Scaling

```
Current: 1 vCPU, 2 GB RAM (Flask)
         0.5 vCPU, 1 GB RAM (Celery worker)
         ↓ (Scale up at 80% memory)
Target:  2 vCPU, 4 GB RAM (Flask)
         1 vCPU, 2 GB RAM (Celery worker)
```

### Auto-Scaling Triggers

| Metric | Threshold | Action |
|--------|-----------|--------|
| CPU Usage | > 70% for 5 min | Scale out (+1 instance) |
| Memory Usage | > 80% for 3 min | Scale up (vertical) |
| Queue Length | > 50 tasks | Scale out Celery workers |
| Request Rate | > 25 req/min | Scale out Flask instances |
| Error Rate | > 5% for 10 min | Alert + investigate |

---

## 🔄 Disaster Recovery

### Failure Scenarios & Recovery

```
┌─────────────────────────────────────────────────────────────────┐
│                    Failure Handling Strategy                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Scenario 1: Primary Model (Sonnet 4.5) Throttled              │
│  └─ Automatic fallback to Sonnet 4.0 → 3.7 → 3.5 → 3.5v2       │
│     Recovery: Automatic (5 models provide redundancy)           │
│     Impact: Minimal (< 1 second delay)                          │
│                                                                 │
│  Scenario 2: All Models Throttled                              │
│  └─ Exponential backoff: 5s → 10s → 20s                        │
│     Recovery: Automatic retry with backoff                      │
│     Impact: Moderate (20-60 second delay)                       │
│                                                                 │
│  Scenario 3: Redis Connection Lost                             │
│  └─ Celery tasks queue in memory                               │
│     Recovery: Reconnect with exponential backoff                │
│     Impact: High (task processing paused)                       │
│     Mitigation: Use Redis cluster with replicas                 │
│                                                                 │
│  Scenario 4: Celery Worker Crash                               │
│  └─ Task rejected and requeued (task_acks_late=True)           │
│     Recovery: Automatic (other workers pick up task)            │
│     Impact: Minimal (< 5 second delay)                          │
│                                                                 │
│  Scenario 5: Flask App Crash                                    │
│  └─ Users see 503 error                                        │
│     Recovery: App Runner auto-restart (health check)            │
│     Impact: Moderate (30-60 second downtime)                    │
│                                                                 │
│  Scenario 6: AWS Bedrock Region Outage (us-east-2)             │
│  └─ Circuit breaker opens, all requests fail                   │
│     Recovery: Manual (switch region or wait for AWS)            │
│     Impact: Critical (complete service outage)                  │
│     Mitigation: Multi-region deployment (future)                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📝 Architecture Evolution

### Version History

| Version | Date | Key Changes |
|---------|------|-------------|
| v1.0 | Pre-Nov 2025 | Single model (Sonnet 3.5), synchronous processing, basic rate limiting |
| v1.5 | Nov 10, 2025 | Added Celery async processing, Redis integration, improved rate limiting |
| v2.0 | Nov 19, 2025 | **Current**: 5-model fallback, extended thinking, us-east-2 region, integrated async components |

### Future Roadmap (v2.1 - v3.0)

```
┌─────────────────────────────────────────────────────────────────┐
│                    Future Enhancements                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  v2.1 (Q1 2026):                                                │
│  ├─ PostgreSQL for persistent session storage                  │
│  ├─ Thread-safe session management (Flask-Session)             │
│  ├─ Real-time WebSocket updates (Socket.IO)                    │
│  └─ Advanced analytics dashboard                               │
│                                                                 │
│  v2.5 (Q2 2026):                                                │
│  ├─ Multi-region deployment (us-east-2 + us-west-2)            │
│  ├─ Model performance ML optimization                          │
│  ├─ Cost optimization AI (automatic model selection)           │
│  └─ A/B testing framework                                      │
│                                                                 │
│  v3.0 (Q3 2026):                                                │
│  ├─ Kubernetes orchestration (replace ECS)                     │
│  ├─ Distributed tracing (OpenTelemetry)                        │
│  ├─ GraphQL API layer                                          │
│  └─ Fine-tuned custom models                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎓 Architecture Principles

### Design Patterns Used

1. **Circuit Breaker Pattern**
   - Location: [core/async_request_manager.py](core/async_request_manager.py)
   - Purpose: Prevent cascade failures from AWS Bedrock throttling

2. **Fallback Pattern**
   - Location: [celery_tasks_enhanced.py](celery_tasks_enhanced.py)
   - Purpose: Provide 5-tier model redundancy

3. **Rate Limiting Pattern**
   - Location: [core/async_request_manager.py](core/async_request_manager.py), [celery_config.py](celery_config.py)
   - Purpose: Prevent API quota exhaustion

4. **Retry with Exponential Backoff**
   - Location: [celery_tasks_enhanced.py](celery_tasks_enhanced.py)
   - Purpose: Graceful recovery from transient failures

5. **Singleton Pattern**
   - Location: [core/async_request_manager.py](core/async_request_manager.py)
   - Purpose: Single shared rate limiter instance

6. **Producer-Consumer Pattern**
   - Location: [app.py](app.py) + Celery Workers
   - Purpose: Decouple request handling from processing

---

**Architecture Document Version**: 2.0
**Last Updated**: November 19, 2025
**Maintained By**: AI-Prism Development Team
**Status**: Production Ready ✅
