# 🏛️ Technical Architecture & System Design
**AI-Prism Document Analysis Tool**

---

## 📐 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            USER INTERFACE LAYER                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  Web Browser (HTML/CSS/JavaScript)                                     │ │
│  │  • responsive_interface.py renders UI                                  │ │
│  │  • static/js/*.js provides client-side logic                          │ │
│  │  • Fetch API for async communication                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │ HTTP/HTTPS (Port 5000)
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                       FLASK APPLICATION LAYER (app.py)                       │
│  ┌─────────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ │
│  │  45 REST API    │  │   Session    │  │  Document    │  │   Error     │ │
│  │   Endpoints     │  │  Management  │  │   Upload     │  │  Handling   │ │
│  │                 │  │   (Flask     │  │   Handler    │  │             │ │
│  │  • /upload      │  │   session)   │  │              │  │  Try/Except │ │
│  │  • /analyze     │  │              │  │   Werkzeug   │  │  Fallbacks  │ │
│  │  • /chat        │  │  sessions{}  │  │   Security   │  │             │ │
│  │  • /feedback    │  │              │  │              │  │             │ │
│  │  • /statistics  │  │              │  │              │  │             │ │
│  │  • /export      │  │              │  │              │  │             │ │
│  └─────────────────┘  └──────────────┘  └──────────────┘  └─────────────┘ │
└───────────┬─────────────────────────────────────────────────────────────────┘
            │
            ├──────────────┬──────────────┬──────────────┬──────────────┬──────
            ▼              ▼              ▼              ▼              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CORE BUSINESS LOGIC LAYER                           │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  DOCUMENT PROCESSING                                                  │  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │  │
│  │  │ DocumentAnalyzer │  │DocumentProcessor │  │ PatternAnalyzer  │  │  │
│  │  │                  │  │                  │  │                  │  │  │
│  │  │ • Extract        │  │ • Generate       │  │ • Find patterns  │  │  │
│  │  │   sections       │  │   DOCX           │  │ • Trend analysis │  │  │
│  │  │ • Parse content  │  │ • Add comments   │  │ • Risk patterns  │  │  │
│  │  │ • Identify       │  │ • Format output  │  │ • Learning       │  │  │
│  │  │   structure      │  │                  │  │                  │  │  │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  AI PROCESSING (CURRENT - OLD)                                        │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐ │  │
│  │  │  AIFeedbackEngine (core/ai_feedback_engine.py)                  │ │  │
│  │  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐   │ │  │
│  │  │  │ analyze_       │  │ process_chat_  │  │ test_          │   │ │  │
│  │  │  │ section()      │  │ query()        │  │ connection()   │   │ │  │
│  │  │  └────────┬───────┘  └────────┬───────┘  └────────┬───────┘   │ │  │
│  │  │           │                   │                   │             │ │  │
│  │  │           └───────────────────┴───────────────────┘             │ │  │
│  │  │                               ▼                                 │ │  │
│  │  │                    _invoke_bedrock()                            │ │  │
│  │  │                               │                                 │ │  │
│  │  │                               │ Uses OLD Prompts                │ │  │
│  │  │                               ▼                                 │ │  │
│  │  │                    config/ai_prompts.py                         │ │  │
│  │  │                    • SECTION_ANALYSIS_PROMPT                    │ │  │
│  │  │                    • CHAT_QUERY_PROMPT                          │ │  │
│  │  └─────────────────────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  AI PROCESSING (NEW - NOT YET INTEGRATED) ⚠️                         │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐ │  │
│  │  │  Async Request Manager (core/async_request_manager.py)          │ │  │
│  │  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐   │ │  │
│  │  │  │ Rate Limiting  │  │ Token Counter  │  │ Circuit Breaker│   │ │  │
│  │  │  │ • 30 req/min   │  │ • Track usage  │  │ • Auto-recover │   │ │  │
│  │  │  │ • 5 concurrent │  │ • 120K TPM     │  │ • Health check │   │ │  │
│  │  │  └────────────────┘  └────────────────┘  └────────────────┘   │ │  │
│  │  └─────────────────────────────────────────────────────────────────┘ │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐ │  │
│  │  │  Bedrock Prompt Templates (config/bedrock_prompt_templates.py) │ │  │
│  │  │  • AWS Best Practices                                           │ │  │
│  │  │  • Token-Optimized                                              │ │  │
│  │  │  • Claude-Specific                                              │ │  │
│  │  └─────────────────────────────────────────────────────────────────┘ │  │
│  │  ┌─────────────────────────────────────────────────────────────────┐ │  │
│  │  │  TOON Serializer (core/toon_serializer.py)                     │ │  │
│  │  │  • 35-40% token savings                                         │ │  │
│  │  │  • Bidirectional conversion                                     │ │  │
│  │  └─────────────────────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  STATISTICS & MONITORING                                              │  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │  │
│  │  │StatisticsManager │  │  AuditLogger     │  │ ActivityLogger   │  │  │
│  │  │                  │  │                  │  │                  │  │  │
│  │  │ • Track metrics  │  │ • Log actions    │  │ • Log activities │  │  │
│  │  │ • Generate stats │  │ • Audit trail    │  │ • Timeline       │  │  │
│  │  │ • Breakdown      │  │ • Performance    │  │ • Export logs    │  │  │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  EXPORT & STORAGE                                                     │  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │  │
│  │  │ S3ExportManager  │  │ Local File       │  │ Learning System  │  │  │
│  │  │                  │  │ Storage          │  │                  │  │  │
│  │  │ • Upload to S3   │  │ • Save locally   │  │ • Pattern learn  │  │  │
│  │  │ • Test connection│  │ • Temp files     │  │ • Recommendations│  │  │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└───────────────────────┬──────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ASYNC TASK QUEUE LAYER                               │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  CELERY DISTRIBUTED TASK QUEUE                                        │  │
│  │  ┌────────────────────────────────────────────────────────────────┐  │  │
│  │  │  Celery Workers (celery_tasks_enhanced.py) ⚠️ NOT ACTIVE       │  │  │
│  │  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐   │  │  │
│  │  │  │ analyze_       │  │ process_chat_  │  │ monitor_       │   │  │  │
│  │  │  │ section_task   │  │ task           │  │ health         │   │  │  │
│  │  │  │                │  │                │  │                │   │  │  │
│  │  │  │ • Multi-model  │  │ • Context mgmt │  │ • Periodic     │   │  │  │
│  │  │  │   fallback     │  │ • History      │  │ • Statistics   │   │  │  │
│  │  │  │ • Retry logic  │  │                │  │ • Health check │   │  │  │
│  │  │  └────────────────┘  └────────────────┘  └────────────────┘   │  │  │
│  │  └────────────────────────────────────────────────────────────────┘  │  │
│  │                                                                        │  │
│  │  ┌────────────────────────────────────────────────────────────────┐  │  │
│  │  │  OLD Celery Workers (celery_tasks.py) ⚠️ CURRENTLY ACTIVE      │  │  │
│  │  │  • Basic task processing                                        │  │  │
│  │  │  • No multi-model fallback                                      │  │  │
│  │  │  • No rate limiting integration                                 │  │  │
│  │  └────────────────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  REDIS MESSAGE BROKER                                                 │  │
│  │  • Task queue storage                                                 │  │
│  │  • Result backend                                                     │  │
│  │  • Distributed coordination                                           │  │
│  │  • Rate limit tracking (for new async manager)                        │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└───────────────────────┬──────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         EXTERNAL SERVICES LAYER                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  AWS BEDROCK                                                          │  │
│  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐         │  │
│  │  │ Claude 3.5     │  │ Claude 3.5 v2  │  │ Claude 3       │         │  │
│  │  │ Sonnet         │  │ (Fallback)     │  │ Sonnet/Haiku   │         │  │
│  │  │ (Primary)      │  │                │  │ (Fallback)     │         │  │
│  │  └────────────────┘  └────────────────┘  └────────────────┘         │  │
│  │                                                                        │  │
│  │  API Limits:                                                          │  │
│  │  • 100 requests/minute per region                                     │  │
│  │  • 200K tokens/minute per region                                      │  │
│  │  • Max tokens per request: 8192                                       │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  AWS S3                                                               │  │
│  │  • Document export                                                    │  │
│  │  • Activity log storage                                               │  │
│  │  • Backup storage                                                     │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                         PERSISTENCE LAYER                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  FILE SYSTEM                                                          │  │
│  │  • uploads/ - Uploaded documents                                      │  │
│  │  • generated_documents/ - Output files                                │  │
│  │  • guidelines/ - Hawkeye checklist                                    │  │
│  │  • logs/ - Application logs                                           │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  IN-MEMORY STATE (app.py globals)                                    │  │
│  │  • sessions{} - Session data (⚠️ not thread-safe)                    │  │
│  │  • ai_engine - AIFeedbackEngine instance                              │  │
│  │  • stats_manager - StatisticsManager instance                         │  │
│  │  • pattern_analyzer - PatternAnalyzer instance                        │  │
│  │  • learning_system - LearningSystem instance                          │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagrams

### Flow 1: Document Upload & Analysis (CURRENT)

```
┌──────────┐
│ User     │
│ Browser  │
└────┬─────┘
     │ 1. Upload DOCX
     ▼
┌─────────────────┐
│ POST /upload    │
│ (app.py:220)    │
└────┬────────────┘
     │ 2. Save file securely
     ▼
┌──────────────────────────┐
│ DocumentAnalyzer         │
│ extract_sections_from_   │
│ docx()                   │
└────┬─────────────────────┘
     │ 3. Return sections
     ▼
┌──────────────────────────┐
│ Store in sessions{}      │
│ (session_id as key)      │
└────┬─────────────────────┘
     │ 4. Return section list
     ▼
┌──────────┐
│ User     │
│ Browser  │
│ (displays│
│ sections)│
└──────────┘

User clicks "Analyze Section"
     │
     ▼
┌─────────────────────────┐
│ POST /analyze_section   │
│ (app.py:321)            │
└────┬────────────────────┘
     │ 5. Get section content
     ▼
┌──────────────────────────┐
│ Check if Celery enabled  │
└────┬──────────┬──────────┘
     │          │
     │ Yes      │ No
     ▼          ▼
┌──────────┐  ┌─────────────────────┐
│ Async    │  │ Synchronous         │
│ (Celery) │  │ (Direct call)       │
└────┬─────┘  └────┬────────────────┘
     │             │
     ▼             ▼
┌──────────────────────────────────┐
│ celery_tasks.analyze_section_    │
│ task() ⚠️ OLD                    │
│   OR                              │
│ ai_engine.analyze_section()       │
└────┬─────────────────────────────┘
     │ 6. Build prompts
     ▼
┌──────────────────────────────────┐
│ config/ai_prompts.py             │
│ • SECTION_ANALYSIS_PROMPT        │
│ • build_section_analysis_prompt()│
└────┬─────────────────────────────┘
     │ 7. Prompt ready
     ▼
┌──────────────────────────────────┐
│ _invoke_bedrock()                │
│ (retry logic, timeout: 180s)     │
└────┬─────────────────────────────┘
     │ 8. API call
     ▼
┌──────────────────────────────────┐
│ AWS Bedrock Runtime API          │
│ invoke_model()                   │
│ • Claude 3.5 Sonnet              │
└────┬─────────────────────────────┘
     │ 9. AI response (JSON)
     ▼
┌──────────────────────────────────┐
│ Parse JSON response              │
│ • Extract feedback_items[]       │
│ • Filter by confidence >= 0.80   │
└────┬─────────────────────────────┘
     │ 10. Return feedback
     ▼
┌──────────────────────────────────┐
│ Store in sessions[session_id]    │
│ ['sections'][section_name]       │
│ ['feedback']                     │
└────┬─────────────────────────────┘
     │ 11. Return to user
     ▼
┌──────────┐
│ User     │
│ Browser  │
│ (displays│
│ feedback)│
└──────────┘
```

### Flow 2: Document Analysis (NEW - Not Active Yet) ⚠️

```
User clicks "Analyze Section"
     │
     ▼
┌─────────────────────────────────┐
│ POST /analyze_section           │
│ (app.py:321) ⚠️ NEEDS UPDATE   │
└────┬────────────────────────────┘
     │ 1. Submit to enhanced queue
     ▼
┌─────────────────────────────────┐
│ celery_tasks_enhanced.          │
│ analyze_section_task.delay()    │
└────┬────────────────────────────┘
     │ 2. Return task_id immediately
     │
     │ [User polls /task_status/<task_id>]
     │
     ▼
┌─────────────────────────────────────┐
│ EnhancedAnalysisTask (Celery worker)│
└────┬────────────────────────────────┘
     │ 3. Check rate limits
     ▼
┌─────────────────────────────────────┐
│ async_request_manager.              │
│ wait_for_rate_limit()               │
│ ┌─────────────────────────────────┐ │
│ │ ✓ Check: 30 requests/min        │ │
│ │ ✓ Check: 5 concurrent max       │ │
│ │ ✓ Check: 120K tokens/min        │ │
│ │ ✓ Wait if needed                │ │
│ └─────────────────────────────────┘ │
└────┬────────────────────────────────┘
     │ 4. Rate limit OK
     ▼
┌─────────────────────────────────────┐
│ BedrockPromptTemplate.              │
│ build_analysis_prompt()             │
│ ┌─────────────────────────────────┐ │
│ │ • AWS best practice format      │ │
│ │ • TOON-encoded framework        │ │
│ │ • Token-optimized               │ │
│ │ • Step-by-step instructions     │ │
│ └─────────────────────────────────┘ │
└────┬────────────────────────────────┘
     │ 5. Optimized prompts
     ▼
┌─────────────────────────────────────┐
│ EnhancedAnalysisTask.               │
│ invoke_with_fallback()              │
│ ┌─────────────────────────────────┐ │
│ │ Try Model 1: Claude 3.5 Sonnet  │ │
│ │           ↓                     │ │
│ │       Success?                  │ │
│ │      ✓ Yes → Return             │ │
│ │      ✗ No (503/Throttle) ↓     │ │
│ │                                 │ │
│ │ Mark throttled, wait 5s         │ │
│ │           ↓                     │ │
│ │ Try Model 2: Claude 3.5 v2      │ │
│ │           ↓                     │ │
│ │       Success?                  │ │
│ │      ✓ Yes → Return             │ │
│ │      ✗ No (503) ↓              │ │
│ │                                 │ │
│ │ Try Model 3: Claude 3 Sonnet    │ │
│ │           ↓                     │ │
│ │       Success?                  │ │
│ │      ✓ Yes → Return             │ │
│ │      ✗ No ↓                    │ │
│ │                                 │ │
│ │ Try Model 4: Claude 3 Haiku     │ │
│ │           ↓                     │ │
│ │       Success? → Return         │ │
│ │       All failed? → Retry task  │ │
│ └─────────────────────────────────┘ │
└────┬────────────────────────────────┘
     │ 6. Success (one model worked)
     ▼
┌─────────────────────────────────────┐
│ Record telemetry:                   │
│ • Request successful                │
│ • Model used                        │
│ • Tokens consumed                   │
│ • Duration                          │
│ • Update circuit breaker            │
└────┬────────────────────────────────┘
     │ 7. Parse & filter response
     ▼
┌─────────────────────────────────────┐
│ Filter feedback:                    │
│ • Confidence >= 0.80                │
│ • Max 10 items                      │
└────┬────────────────────────────────┘
     │ 8. Return result
     ▼
┌──────────┐
│ Celery   │
│ result   │
│ backend  │
│ (Redis)  │
└────┬─────┘
     │ 9. User polls /task_status
     ▼
┌──────────┐
│ User     │
│ Browser  │
│ (displays│
│ feedback)│
└──────────┘
```

### Flow 3: Rate Limiting & Throttling Protection

```
Multiple concurrent requests arrive
     │
     ├─── Request 1
     ├─── Request 2
     ├─── Request 3
     ├─── Request 4
     ├─── Request 5
     └─── Request 6
     │
     ▼
┌──────────────────────────────────────┐
│ AsyncRequestManager                  │
│ (Centralized coordinator)            │
└────┬─────────────────────────────────┘
     │
     │ For each request:
     ▼
┌──────────────────────────────────────┐
│ Layer 1: Concurrent Limit Check     │
│ ┌──────────────────────────────────┐ │
│ │ active_requests < 5?             │ │
│ │   YES → Continue                 │ │
│ │   NO → Wait (sleep 1s, retry)    │ │
│ └──────────────────────────────────┘ │
└────┬─────────────────────────────────┘
     │ ✓ Passed
     ▼
┌──────────────────────────────────────┐
│ Layer 2: Request Rate Limit         │
│ ┌──────────────────────────────────┐ │
│ │ requests_last_minute < 30?       │ │
│ │   YES → Continue                 │ │
│ │   NO → Wait until oldest expires │ │
│ └──────────────────────────────────┘ │
└────┬─────────────────────────────────┘
     │ ✓ Passed
     ▼
┌──────────────────────────────────────┐
│ Layer 3: Token Rate Limit           │
│ ┌──────────────────────────────────┐ │
│ │ tokens_last_minute + estimated   │ │
│ │ < 120,000?                       │ │
│ │   YES → Continue                 │ │
│ │   NO → Wait (60s max)            │ │
│ └──────────────────────────────────┘ │
└────┬─────────────────────────────────┘
     │ ✓ All checks passed
     ▼
┌──────────────────────────────────────┐
│ Layer 4: Model Health Check         │
│ ┌──────────────────────────────────┐ │
│ │ For each model (priority order): │ │
│ │   Is circuit breaker OPEN?       │ │
│ │     YES → Skip this model        │ │
│ │     NO → Use this model          │ │
│ └──────────────────────────────────┘ │
└────┬─────────────────────────────────┘
     │ ✓ Model available
     ▼
┌──────────────────────────────────────┐
│ Record request start:                │
│ • Increment active_requests          │
│ • Add timestamp to queue             │
│ • Mark model as in-use               │
└────┬─────────────────────────────────┘
     │
     ▼
┌──────────────────────────────────────┐
│ INVOKE AWS BEDROCK API               │
└────┬──────────────┬──────────────────┘
     │              │
     │ Success      │ Error (503/Throttle)
     ▼              ▼
┌──────────────┐  ┌──────────────────────┐
│ Layer 5:     │  │ Layer 5:             │
│ Success Path │  │ Error Recovery       │
│              │  │                      │
│ • Record     │  │ • Mark model         │
│   success    │  │   throttled          │
│ • Reset      │  │ • Open circuit       │
│   circuit    │  │   breaker            │
│ • Update     │  │ • Set cooldown       │
│   stats      │  │   (60s * count)      │
│ • Decrement  │  │ • Try next model     │
│   active     │  │                      │
└──────────────┘  └──────────┬───────────┘
                             │
                             │ All models failed?
                             ▼
                    ┌──────────────────────┐
                    │ Layer 6:             │
                    │ Exponential Backoff  │
                    │                      │
                    │ Retry = 2^attempt    │
                    │ Max 3 retries        │
                    │ Jitter added         │
                    └──────────────────────┘
```

---

## 📦 Component Interaction Matrix

| Component | Interacts With | Purpose | Status |
|-----------|---------------|---------|--------|
| **app.py** | All components | Main orchestrator | ✅ Active |
| **DocumentAnalyzer** | app.py | Section extraction | ✅ Active |
| **AIFeedbackEngine** | app.py, celery_tasks | Analysis logic | ✅ Active |
| **celery_tasks** | app.py, AIFeedbackEngine | OLD async processing | ✅ Active |
| **celery_tasks_enhanced** | None | NEW async processing | ❌ Not integrated |
| **AsyncRequestManager** | celery_tasks_enhanced | Rate limiting | ❌ Not used |
| **TOON Serializer** | bedrock_prompt_templates | Token optimization | ❌ Not used |
| **BedrockPromptTemplates** | celery_tasks_enhanced | AWS prompts | ❌ Not used |
| **StatisticsManager** | app.py | Metrics tracking | ✅ Active |
| **PatternAnalyzer** | app.py | Pattern detection | ✅ Active |
| **S3ExportManager** | app.py | S3 operations | ✅ Active |
| **Redis** | Celery, AsyncRequestManager | Message broker | ✅ Required |
| **AWS Bedrock** | AIFeedbackEngine | AI processing | ✅ Active |

---

## 🔐 Security Architecture

### Authentication & Authorization
```
Currently: None (single-user system)

Recommended for multi-user:
┌───────────────────────────────────┐
│ User Authentication               │
│ • OAuth 2.0 / SAML                │
│ • JWT tokens                      │
│ • Session management              │
└───────────────┬───────────────────┘
                ▼
┌───────────────────────────────────┐
│ Authorization                     │
│ • Role-based access control       │
│ • Document ownership              │
│ • API key for programmatic access │
└───────────────────────────────────┘
```

### Data Security
```
┌───────────────────────────────────┐
│ In Transit                        │
│ • HTTPS/TLS for web traffic       │
│ • AWS Sig V4 for Bedrock API      │
│ • Redis TLS (production)          │
└───────────────────────────────────┘

┌───────────────────────────────────┐
│ At Rest                           │
│ • Encrypted S3 buckets            │
│ • Secure file permissions         │
│ • Environment variables for keys  │
└───────────────────────────────────┘

┌───────────────────────────────────┐
│ Application                       │
│ • Input validation                │
│ • secure_filename() for uploads   │
│ • No SQL injection risk (no DB)   │
│ • CORS headers configured         │
└───────────────────────────────────┘
```

### AWS Security
```
┌───────────────────────────────────┐
│ IAM Roles & Policies              │
│                                   │
│ Bedrock Access:                   │
│ • bedrock:InvokeModel             │
│ • Restricted to specific models   │
│                                   │
│ S3 Access:                        │
│ • s3:PutObject                    │
│ • s3:GetObject                    │
│ • Restricted to specific bucket   │
└───────────────────────────────────┘
```

---

## 📈 Scalability Architecture

### Current Limitations
```
┌────────────────────────────────────┐
│ Scalability Constraints            │
│                                    │
│ • Single Flask instance            │
│ • In-memory sessions{}             │
│ • Local file storage               │
│ • No database                      │
│ • Shared global state              │
└────────────────────────────────────┘

Max Capacity:
• ~10-15 concurrent users
• ~30 requests/minute (AWS limit)
• Single machine resources
```

### Recommended Scale-Out Architecture
```
┌─────────────────────────────────────────────────────────────┐
│ Load Balancer (Application Load Balancer)                   │
└────────┬────────────────────┬───────────────────────────────┘
         │                    │
         ▼                    ▼
┌─────────────────┐  ┌─────────────────┐
│ Flask Instance 1│  │ Flask Instance 2│  ... N instances
│ (Docker/ECS)    │  │ (Docker/ECS)    │
└────────┬────────┘  └────────┬────────┘
         │                    │
         └────────────┬───────┘
                      │
                      ▼
┌──────────────────────────────────────────┐
│ Shared Session Store (Redis/ElastiCache)│
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│ Shared File Storage (EFS/S3)             │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│ Celery Workers (Auto-scaling group)      │
│ • Scale based on queue depth             │
│ • 4-20 workers                           │
└──────────────────────────────────────────┘

Max Capacity (with scale-out):
• 100+ concurrent users
• 1000+ requests/minute (multi-region)
• Horizontal scaling
```

---

## 🎯 Technology Stack Summary

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| **Frontend** | HTML/CSS/JavaScript | ES6+ | User interface |
| **Web Framework** | Flask | 2.x | HTTP server |
| **Task Queue** | Celery | 5.x | Async processing |
| **Message Broker** | Redis | 7.x | Task queue backend |
| **AI Service** | AWS Bedrock | - | Claude models |
| **Document Processing** | python-docx | 0.8.x | DOCX parsing |
| **HTTP Client** | boto3 | 1.x | AWS SDK |
| **Serialization** | JSON, TOON | - | Data format |
| **Cloud Storage** | AWS S3 | - | File storage |
| **Monitoring** | Celery Flower | 2.x | Task monitoring |

---

## 🔄 Deployment Architecture

### Development Environment
```
┌─────────────────────────────────────┐
│ Local Machine                       │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ Terminal 1: Flask app           │ │
│ │ python app.py                   │ │
│ └─────────────────────────────────┘ │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ Terminal 2: Celery worker       │ │
│ │ celery -A celery_config worker  │ │
│ └─────────────────────────────────┘ │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ Terminal 3: Redis (Docker)      │ │
│ │ docker run redis:latest         │ │
│ └─────────────────────────────────┘ │
└─────────────────────────────────────┘
```

### Production Architecture (Recommended)
```
┌───────────────────────────────────────────────────────────┐
│ AWS Cloud                                                  │
│                                                            │
│ ┌─────────────────────────────────────────────────────┐  │
│ │ VPC (us-east-1)                                     │  │
│ │                                                      │  │
│ │ ┌───────────────────────────────────────────────┐  │  │
│ │ │ Public Subnet                                 │  │  │
│ │ │                                                │  │  │
│ │ │ ┌──────────────────────────────────────────┐ │  │  │
│ │ │ │ Application Load Balancer                │ │  │  │
│ │ │ │ • HTTPS (Port 443)                       │ │  │  │
│ │ │ │ • SSL Certificate (ACM)                  │ │  │  │
│ │ │ └────────────────┬─────────────────────────┘ │  │  │
│ │ └──────────────────┼───────────────────────────┘  │  │
│ │                    │                               │  │
│ │ ┌──────────────────┼───────────────────────────┐  │  │
│ │ │ Private Subnet 1 │                           │  │  │
│ │ │                  ▼                           │  │  │
│ │ │ ┌────────────────────────────────────────┐  │  │  │
│ │ │ │ ECS Fargate - Flask App                │  │  │  │
│ │ │ │ • Auto-scaling (2-10 tasks)            │  │  │  │
│ │ │ │ • Health checks                        │  │  │  │
│ │ │ └────────────────────────────────────────┘  │  │  │
│ │ └──────────────────────────────────────────────┘  │  │
│ │                                                    │  │
│ │ ┌──────────────────────────────────────────────┐  │  │
│ │ │ Private Subnet 2                             │  │  │
│ │ │                                               │  │  │
│ │ │ ┌────────────────────────────────────────┐  │  │  │
│ │ │ │ ECS Fargate - Celery Workers           │  │  │  │
│ │ │ │ • Auto-scaling (4-20 tasks)            │  │  │  │
│ │ │ │ • Queue-based scaling                  │  │  │  │
│ │ │ └────────────────────────────────────────┘  │  │  │
│ │ │                                               │  │  │
│ │ │ ┌────────────────────────────────────────┐  │  │  │
│ │ │ │ ElastiCache Redis                      │  │  │  │
│ │ │ │ • Multi-AZ                             │  │  │  │
│ │ │ │ • Persistence enabled                  │  │  │  │
│ │ │ └────────────────────────────────────────┘  │  │  │
│ │ └──────────────────────────────────────────────┘  │  │
│ └─────────────────────────────────────────────────┘  │
│                                                        │
│ ┌─────────────────────────────────────────────────┐  │
│ │ S3 Bucket                                       │  │
│ │ • Versioning enabled                            │  │
│ │ • Encryption at rest                            │  │
│ │ • Lifecycle policies                            │  │
│ └─────────────────────────────────────────────────┘  │
│                                                        │
│ ┌─────────────────────────────────────────────────┐  │
│ │ CloudWatch                                      │  │
│ │ • Logs aggregation                              │  │
│ │ • Metrics & alarms                              │  │
│ │ • Dashboard                                     │  │
│ └─────────────────────────────────────────────────┘  │
│                                                        │
│ ┌─────────────────────────────────────────────────┐  │
│ │ Bedrock (us-east-1)                             │  │
│ │ • Claude models                                 │  │
│ │ • API Gateway                                   │  │
│ └─────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────┘
```

---

**End of Technical Architecture Document**

*Last Updated: November 19, 2025*
*Document Version: 1.0*
