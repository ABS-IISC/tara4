"""
AWS Region Configuration Module
================================
Centralized region management for multi-region deployment.

This module provides automatic region detection, validation, and fallback
mechanisms to make the application work seamlessly across all AWS regions.

Features:
- Auto-detects region from multiple sources (environment, EC2 metadata, IAM)
- Validates Bedrock Claude model availability per region
- Validates S3 bucket accessibility per region
- Provides intelligent fallback ordering
- Thread-safe caching of region configuration

Usage:
    from config.aws_regions import get_region_config, validate_region_setup

    config = get_region_config()
    print(f"Using region: {config['region']}")

    # Validate setup
    is_valid, errors = validate_region_setup()
"""

import os
import boto3
import requests
from typing import Dict, List, Tuple, Optional
from functools import lru_cache
import logging

logger = logging.getLogger(__name__)


# ============================================================================
# ALL AWS REGIONS WITH BEDROCK SUPPORT
# ============================================================================

# Complete list of ALL AWS regions (as of 2025)
# Includes all regions whether Bedrock is enabled or not
ALL_AWS_REGIONS = [
    # United States (All Enabled by Default)
    'us-east-1',      # United States (N. Virginia) - Enabled by default
    'us-east-2',      # United States (Ohio) - Enabled by default
    'us-west-1',      # United States (N. California) - Enabled by default
    'us-west-2',      # United States (Oregon) - Enabled by default

    # Canada
    'ca-central-1',   # Canada (Central) - Enabled by default
    'ca-west-1',      # Canada (Calgary) - Disabled

    # South America
    'sa-east-1',      # South America (São Paulo) - Enabled by default
    'mx-central-1',   # Mexico (Central) - Disabled

    # Europe
    'eu-north-1',     # Europe (Stockholm) - Enabled by default
    'eu-west-1',      # Europe (Ireland) - Enabled by default
    'eu-west-2',      # Europe (London) - Enabled by default
    'eu-west-3',      # Europe (Paris) - Enabled by default
    'eu-central-1',   # Europe (Frankfurt) - Enabled by default
    'eu-central-2',   # Europe (Zurich) - Disabled
    'eu-south-1',     # Europe (Milan) - Disabled
    'eu-south-2',     # Europe (Spain) - Enabled

    # Asia Pacific
    'ap-south-1',     # Asia Pacific (Mumbai) - Enabled by default
    'ap-south-2',     # Asia Pacific (Hyderabad) - Disabled
    'ap-northeast-1', # Asia Pacific (Tokyo) - Enabled by default
    'ap-northeast-2', # Asia Pacific (Seoul) - Enabled by default
    'ap-northeast-3', # Asia Pacific (Osaka) - Enabled by default
    'ap-southeast-1', # Asia Pacific (Singapore) - Enabled by default
    'ap-southeast-2', # Asia Pacific (Sydney) - Enabled by default
    'ap-southeast-3', # Asia Pacific (Jakarta) - Disabled
    'ap-southeast-4', # Asia Pacific (Melbourne) - Disabled
    'ap-southeast-5', # Asia Pacific (Malaysia) - Disabled
    'ap-southeast-6', # Asia Pacific (New Zealand) - Disabled
    'ap-southeast-7', # Asia Pacific (Thailand) - Disabled
    'ap-east-1',      # Asia Pacific (Hong Kong) - Disabled
    'ap-southeast-8', # Asia Pacific (Taipei) - Disabled

    # Middle East
    'me-south-1',     # Middle East (Bahrain) - Disabled
    'me-central-1',   # Middle East (UAE) - Disabled

    # Africa
    'af-south-1',     # Africa (Cape Town) - Disabled

    # Israel
    'il-central-1',   # Israel (Tel Aviv) - Disabled
]

# Regions where Amazon Bedrock is available (as of Jan 2025)
# Based on the user's region availability list
BEDROCK_SUPPORTED_REGIONS = [
    # United States (All Enabled by Default)
    'us-east-1',      # United States (N. Virginia) - PRIMARY - Enabled by default
    'us-east-2',      # United States (Ohio) - Enabled by default
    'us-west-1',      # United States (N. California) - Enabled by default
    'us-west-2',      # United States (Oregon) - Enabled by default

    # Canada
    'ca-central-1',   # Canada (Central) - Enabled by default

    # South America
    'sa-east-1',      # South America (São Paulo) - Enabled by default

    # Europe (Enabled by Default)
    'eu-north-1',     # Europe (Stockholm) - Enabled by default
    'eu-west-1',      # Europe (Ireland) - Enabled by default
    'eu-west-2',      # Europe (London) - Enabled by default
    'eu-west-3',      # Europe (Paris) - Enabled by default
    'eu-central-1',   # Europe (Frankfurt) - Enabled by default
    'eu-south-2',     # Europe (Spain) - Enabled

    # Asia Pacific (Enabled by Default)
    'ap-south-1',     # Asia Pacific (Mumbai) - Enabled by default
    'ap-northeast-1', # Asia Pacific (Tokyo) - Enabled by default
    'ap-northeast-2', # Asia Pacific (Seoul) - Enabled by default
    'ap-northeast-3', # Asia Pacific (Osaka) - Enabled by default
    'ap-southeast-1', # Asia Pacific (Singapore) - Enabled by default
    'ap-southeast-2', # Asia Pacific (Sydney) - Enabled by default
]

# Claude Sonnet 4.5 model ID format per region
# Some regions use cross-region inference, some use regional model IDs
CLAUDE_MODEL_IDS = {
    # United States - Use US regional model IDs
    'us-east-1': 'us.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'us-east-2': 'us.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'us-west-1': 'us.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'us-west-2': 'us.anthropic.claude-sonnet-4-5-20250929-v1:0',

    # Canada - Use standard model ID
    'ca-central-1': 'anthropic.claude-sonnet-4-5-20250929-v1:0',

    # South America - Use standard model ID
    'sa-east-1': 'anthropic.claude-sonnet-4-5-20250929-v1:0',

    # Europe - Use EU regional model IDs
    'eu-north-1': 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'eu-west-1': 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'eu-west-2': 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'eu-west-3': 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'eu-central-1': 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'eu-south-2': 'eu.anthropic.claude-sonnet-4-5-20250929-v1:0',

    # Asia Pacific - Use APAC regional model IDs
    'ap-south-1': 'apac.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'ap-northeast-1': 'apac.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'ap-northeast-2': 'apac.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'ap-northeast-3': 'apac.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'ap-southeast-1': 'apac.anthropic.claude-sonnet-4-5-20250929-v1:0',
    'ap-southeast-2': 'apac.anthropic.claude-sonnet-4-5-20250929-v1:0',
}

# Preferred region order based on Bedrock performance and cost
PREFERRED_REGION_ORDER = [
    'us-east-1',      # Best Bedrock support, lowest latency
    'us-west-2',      # Good US alternative
    'eu-west-1',      # Best EU support
    'eu-central-1',   # Good EU alternative
    'ap-southeast-1', # Best APAC support
    'ap-northeast-1', # Good APAC alternative
]

# Region display names - ALL AWS regions
REGION_NAMES = {
    # United States
    'us-east-1': 'United States (N. Virginia)',
    'us-east-2': 'United States (Ohio)',
    'us-west-1': 'United States (N. California)',
    'us-west-2': 'United States (Oregon)',

    # Canada
    'ca-central-1': 'Canada (Central)',
    'ca-west-1': 'Canada (Calgary)',

    # South America
    'sa-east-1': 'South America (São Paulo)',
    'mx-central-1': 'Mexico (Central)',

    # Europe
    'eu-north-1': 'Europe (Stockholm)',
    'eu-west-1': 'Europe (Ireland)',
    'eu-west-2': 'Europe (London)',
    'eu-west-3': 'Europe (Paris)',
    'eu-central-1': 'Europe (Frankfurt)',
    'eu-central-2': 'Europe (Zurich)',
    'eu-south-1': 'Europe (Milan)',
    'eu-south-2': 'Europe (Spain)',

    # Asia Pacific
    'ap-south-1': 'Asia Pacific (Mumbai)',
    'ap-south-2': 'Asia Pacific (Hyderabad)',
    'ap-northeast-1': 'Asia Pacific (Tokyo)',
    'ap-northeast-2': 'Asia Pacific (Seoul)',
    'ap-northeast-3': 'Asia Pacific (Osaka)',
    'ap-southeast-1': 'Asia Pacific (Singapore)',
    'ap-southeast-2': 'Asia Pacific (Sydney)',
    'ap-southeast-3': 'Asia Pacific (Jakarta)',
    'ap-southeast-4': 'Asia Pacific (Melbourne)',
    'ap-southeast-5': 'Asia Pacific (Malaysia)',
    'ap-southeast-6': 'Asia Pacific (New Zealand)',
    'ap-southeast-7': 'Asia Pacific (Thailand)',
    'ap-southeast-8': 'Asia Pacific (Taipei)',
    'ap-east-1': 'Asia Pacific (Hong Kong)',

    # Middle East
    'me-south-1': 'Middle East (Bahrain)',
    'me-central-1': 'Middle East (UAE)',

    # Africa
    'af-south-1': 'Africa (Cape Town)',

    # Israel
    'il-central-1': 'Israel (Tel Aviv)',
}


# ============================================================================
# REGION DETECTION
# ============================================================================

@lru_cache(maxsize=1)
def detect_current_region() -> Optional[str]:
    """
    Detect current AWS region from multiple sources.

    Priority:
    1. AWS_REGION environment variable (explicit override)
    2. AWS_DEFAULT_REGION environment variable
    3. EC2 instance metadata (if running on EC2/Elastic Beanstalk)
    4. AWS CLI configuration
    5. IAM role region (if using IAM)

    Returns:
        str: Detected region code (e.g., 'us-east-1') or None
    """
    # 1. Check environment variables (highest priority)
    region = os.environ.get('AWS_REGION')
    if region:
        logger.info(f"✅ Region from AWS_REGION env: {region}")
        return region

    region = os.environ.get('AWS_DEFAULT_REGION')
    if region:
        logger.info(f"✅ Region from AWS_DEFAULT_REGION env: {region}")
        return region

    # 2. Try EC2 instance metadata (Elastic Beanstalk, EC2, ECS)
    try:
        # Use IMDSv2 token-based approach
        token_url = 'http://169.254.169.254/latest/api/token'
        metadata_url = 'http://169.254.169.254/latest/meta-data/placement/region'

        # Get IMDSv2 token
        token_response = requests.put(
            token_url,
            headers={'X-aws-ec2-metadata-token-ttl-seconds': '21600'},
            timeout=1
        )

        if token_response.status_code == 200:
            token = token_response.text

            # Get region with token
            region_response = requests.get(
                metadata_url,
                headers={'X-aws-ec2-metadata-token': token},
                timeout=1
            )

            if region_response.status_code == 200:
                region = region_response.text.strip()
                logger.info(f"✅ Region from EC2 metadata: {region}")
                return region
    except Exception as e:
        logger.debug(f"Could not fetch EC2 metadata: {e}")

    # 3. Try AWS CLI default region
    try:
        import configparser
        config_path = os.path.expanduser('~/.aws/config')
        if os.path.exists(config_path):
            config = configparser.ConfigParser()
            config.read(config_path)
            if 'default' in config and 'region' in config['default']:
                region = config['default']['region']
                logger.info(f"✅ Region from AWS CLI config: {region}")
                return region
    except Exception as e:
        logger.debug(f"Could not read AWS CLI config: {e}")

    # 4. Try boto3 session default
    try:
        session = boto3.Session()
        region = session.region_name
        if region:
            logger.info(f"✅ Region from boto3 session: {region}")
            return region
    except Exception as e:
        logger.debug(f"Could not get boto3 session region: {e}")

    logger.warning("⚠️  Could not detect AWS region from any source")
    return None


def get_fallback_region(preferred_region: Optional[str] = None) -> str:
    """
    Get fallback region with intelligent selection.

    Args:
        preferred_region: User's preferred region if detection fails

    Returns:
        str: Best fallback region for Bedrock
    """
    # If preferred region is Bedrock-supported, use it
    if preferred_region and preferred_region in BEDROCK_SUPPORTED_REGIONS:
        return preferred_region

    # Otherwise, use first preferred region with Bedrock
    return PREFERRED_REGION_ORDER[0]  # us-east-1


def get_s3_bucket_region(bucket_name: str) -> Optional[str]:
    """
    Detect the region of an S3 bucket.

    Args:
        bucket_name: Name of the S3 bucket

    Returns:
        str: Region code or None if detection fails
    """
    try:
        s3_client = boto3.client('s3')
        response = s3_client.get_bucket_location(Bucket=bucket_name)

        # Note: us-east-1 returns None in LocationConstraint
        region = response.get('LocationConstraint') or 'us-east-1'
        logger.info(f"✅ S3 bucket '{bucket_name}' is in region: {region}")
        return region
    except Exception as e:
        logger.warning(f"⚠️  Could not detect S3 bucket region: {e}")
        return None


# ============================================================================
# REGION VALIDATION
# ============================================================================

def validate_bedrock_access(region: str) -> Tuple[bool, Optional[str]]:
    """
    Validate that Bedrock Claude model is accessible in the region.

    Args:
        region: AWS region code

    Returns:
        Tuple[bool, str]: (is_accessible, error_message)
    """
    if region not in BEDROCK_SUPPORTED_REGIONS:
        return False, f"Bedrock not available in {region}"

    try:
        bedrock = boto3.client('bedrock', region_name=region)

        # List available models to verify access
        response = bedrock.list_foundation_models(
            byProvider='Anthropic',
            byOutputModality='TEXT'
        )

        # Check if any Claude Sonnet model is available
        models = response.get('modelSummaries', [])
        claude_models = [m for m in models if 'claude-sonnet' in m.get('modelId', '').lower()]

        if claude_models:
            logger.info(f"✅ Bedrock accessible in {region} with {len(claude_models)} Claude models")
            return True, None
        else:
            return False, f"No Claude Sonnet models found in {region}"

    except Exception as e:
        return False, f"Bedrock validation error in {region}: {str(e)}"


def validate_s3_access(bucket_name: str, region: str) -> Tuple[bool, Optional[str]]:
    """
    Validate S3 bucket access in specified region.

    Args:
        bucket_name: S3 bucket name
        region: AWS region code

    Returns:
        Tuple[bool, str]: (is_accessible, error_message)
    """
    try:
        s3_client = boto3.client('s3', region_name=region)

        # Try to list objects (this validates both bucket existence and permissions)
        s3_client.head_bucket(Bucket=bucket_name)

        logger.info(f"✅ S3 bucket '{bucket_name}' accessible from {region}")
        return True, None

    except Exception as e:
        return False, f"S3 validation error: {str(e)}"


# ============================================================================
# MAIN CONFIGURATION FUNCTION
# ============================================================================

@lru_cache(maxsize=1)
def get_region_config(
    force_region: Optional[str] = None,
    s3_bucket_name: Optional[str] = None
) -> Dict[str, any]:
    """
    Get complete region configuration with automatic detection and validation.

    This is the main function to use in your application code.

    Args:
        force_region: Force a specific region (bypasses auto-detection)
        s3_bucket_name: S3 bucket name for region alignment

    Returns:
        Dict with:
            - region: Selected AWS region
            - region_name: Human-readable region name
            - bedrock_region: Region for Bedrock API calls
            - s3_region: Region for S3 operations
            - model_id: Correct Claude model ID for the region
            - is_bedrock_supported: Whether Bedrock is available
            - detection_method: How region was determined
            - fallback_used: Whether fallback was used
    """
    detection_method = "unknown"
    fallback_used = False

    # 1. Determine region
    if force_region:
        region = force_region
        detection_method = "forced"
        logger.info(f"🔧 Using forced region: {region}")
    else:
        region = detect_current_region()
        if region:
            detection_method = "auto-detected"
        else:
            region = get_fallback_region()
            detection_method = "fallback"
            fallback_used = True
            logger.warning(f"⚠️  Using fallback region: {region}")

    # 2. Validate region exists
    if region not in ALL_AWS_REGIONS:
        logger.error(f"❌ Invalid region: {region}. Using fallback.")
        region = get_fallback_region()
        fallback_used = True

    # 3. Determine Bedrock region (may differ from primary region)
    bedrock_region = region
    is_bedrock_supported = region in BEDROCK_SUPPORTED_REGIONS

    if not is_bedrock_supported:
        # Use cross-region inference to nearest Bedrock region
        logger.warning(f"⚠️  Bedrock not available in {region}, using cross-region to {PREFERRED_REGION_ORDER[0]}")
        bedrock_region = PREFERRED_REGION_ORDER[0]

    # 4. Determine S3 region
    s3_region = region
    if s3_bucket_name:
        detected_s3_region = get_s3_bucket_region(s3_bucket_name)
        if detected_s3_region:
            s3_region = detected_s3_region

    # 5. Get correct model ID for region
    model_id = CLAUDE_MODEL_IDS.get(
        bedrock_region,
        'anthropic.claude-sonnet-4-5-20250929-v1:0'  # Generic fallback
    )

    # 6. Build configuration
    config = {
        'region': region,
        'region_name': REGION_NAMES.get(region, region),
        'bedrock_region': bedrock_region,
        's3_region': s3_region,
        'model_id': model_id,
        'is_bedrock_supported': is_bedrock_supported,
        'detection_method': detection_method,
        'fallback_used': fallback_used,
        'all_supported_regions': BEDROCK_SUPPORTED_REGIONS,
    }

    logger.info(f"""
📍 Region Configuration:
   Primary Region: {region} ({REGION_NAMES.get(region, 'Unknown')})
   Bedrock Region: {bedrock_region}
   S3 Region: {s3_region}
   Model ID: {model_id}
   Detection: {detection_method}
   Fallback Used: {fallback_used}
""")

    return config


def validate_region_setup(
    region: Optional[str] = None,
    s3_bucket_name: Optional[str] = None
) -> Tuple[bool, List[str]]:
    """
    Validate complete region setup including Bedrock and S3 access.

    Args:
        region: Region to validate (uses auto-detected if None)
        s3_bucket_name: S3 bucket to validate

    Returns:
        Tuple[bool, List[str]]: (all_valid, list_of_errors)
    """
    errors = []

    # Get region config
    config = get_region_config(force_region=region, s3_bucket_name=s3_bucket_name)
    region = config['region']

    # Validate Bedrock
    bedrock_valid, bedrock_error = validate_bedrock_access(config['bedrock_region'])
    if not bedrock_valid:
        errors.append(f"Bedrock: {bedrock_error}")

    # Validate S3 if bucket name provided
    if s3_bucket_name:
        s3_valid, s3_error = validate_s3_access(s3_bucket_name, config['s3_region'])
        if not s3_valid:
            errors.append(f"S3: {s3_error}")

    is_valid = len(errors) == 0

    if is_valid:
        logger.info(f"✅ Region setup validated successfully for {region}")
    else:
        logger.error(f"❌ Region setup validation failed: {errors}")

    return is_valid, errors


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_supported_regions() -> List[Dict[str, str]]:
    """
    Get list of all Bedrock-supported regions with metadata.

    Returns:
        List of dicts with region info
    """
    return [
        {
            'code': region,
            'name': REGION_NAMES.get(region, region),
            'model_id': CLAUDE_MODEL_IDS.get(region, 'anthropic.claude-sonnet-4-5-20250929-v1:0'),
            'is_preferred': region in PREFERRED_REGION_ORDER[:3]
        }
        for region in BEDROCK_SUPPORTED_REGIONS
    ]


def get_model_id_for_region(region: str) -> str:
    """
    Get the correct Claude model ID for a specific region.

    Args:
        region: AWS region code

    Returns:
        str: Claude model ID
    """
    return CLAUDE_MODEL_IDS.get(
        region,
        'anthropic.claude-sonnet-4-5-20250929-v1:0'
    )


def is_region_supported(region: str) -> bool:
    """
    Check if a region supports Bedrock Claude models.

    Args:
        region: AWS region code

    Returns:
        bool: True if supported
    """
    return region in BEDROCK_SUPPORTED_REGIONS


# ============================================================================
# ENVIRONMENT VARIABLE EXPORT
# ============================================================================

def export_region_to_env(config: Optional[Dict] = None) -> None:
    """
    Export region configuration to environment variables.
    Useful for ensuring consistent region usage across the application.

    Args:
        config: Region config dict (auto-generated if None)
    """
    if config is None:
        config = get_region_config()

    os.environ['AWS_REGION'] = config['region']
    os.environ['AWS_DEFAULT_REGION'] = config['region']
    os.environ['BEDROCK_REGION'] = config['bedrock_region']
    os.environ['S3_REGION'] = config['s3_region']
    os.environ['BEDROCK_MODEL_ID'] = config['model_id']

    logger.info(f"✅ Exported region config to environment variables")


# ============================================================================
# TESTING / DEBUG
# ============================================================================

if __name__ == '__main__':
    # Test region detection
    print("=" * 80)
    print("AWS Region Configuration Test")
    print("=" * 80)

    # Test auto-detection
    print("\n1. Auto-detecting region...")
    config = get_region_config()
    print(f"   Result: {config}")

    # Test validation
    print("\n2. Validating region setup...")
    is_valid, errors = validate_region_setup()
    print(f"   Valid: {is_valid}")
    if errors:
        print(f"   Errors: {errors}")

    # Show all supported regions
    print("\n3. All Bedrock-supported regions:")
    for region_info in get_supported_regions():
        print(f"   - {region_info['code']}: {region_info['name']}")

    print("\n" + "=" * 80)
