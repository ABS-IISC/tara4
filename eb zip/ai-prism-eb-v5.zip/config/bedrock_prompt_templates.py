"""
AWS Bedrock Prompt Templates
Following AWS best practices and Claude prompt engineering guidelines

References:
- https://docs.aws.amazon.com/bedrock/latest/userguide/prompt-templates-and-examples.html
- https://docs.aws.amazon.com/bedrock/latest/APIReference/API_agent-runtime_PromptTemplate.html
- https://github.com/aws-samples/amazon-bedrock-prompting

Key Principles:
1. Clear role definition and context
2. Explicit instructions with examples
3. Output format specification
4. Token-efficient structure
5. Claude-optimized formatting
"""

from typing import Dict, List, Optional
from core.toon_serializer import to_toon


class BedrockPromptTemplate:
    """
    AWS Bedrock-optimized prompt templates for Claude models
    Follows Amazon's recommended prompt engineering patterns
    """

    # ========================================================================
    # SYSTEM PROMPTS (Following AWS Best Practices)
    # ========================================================================

    @staticmethod
    def build_system_prompt(role: str, expertise: List[str], guidelines: Optional[str] = None) -> str:
        """
        Build system prompt following AWS Bedrock best practices

        AWS Recommendations:
        - Clear role definition
        - Specific expertise areas
        - Behavioral guidelines
        - Output expectations

        Args:
            role: Primary role (e.g., "Investigation Analyst")
            expertise: List of expertise areas
            guidelines: Optional additional guidelines

        Returns:
            Optimized system prompt
        """
        prompt = f"""You are {role} with deep expertise in:
{chr(10).join(f'• {area}' for area in expertise)}

Your analysis follows these principles:
• Evidence-based reasoning and systematic evaluation
• Clear identification of gaps, risks, and improvement opportunities
• Actionable recommendations with specific next steps
• Compliance with established frameworks and standards
• Professional investigative methodology"""

        if guidelines:
            prompt += f"\n\nFramework Guidelines:\n{guidelines}"

        prompt += """

Output Requirements:
• Structured JSON format with all required fields
• Precise, concise descriptions (no unnecessary verbosity)
• Specific references to framework checkpoints
• Confidence scores based on evidence strength
• Risk levels aligned with impact assessment"""

        return prompt

    # ========================================================================
    # DOCUMENT ANALYSIS TEMPLATE (AWS Optimized)
    # ========================================================================

    @staticmethod
    def build_analysis_prompt(
        section_name: str,
        content: str,
        framework_checkpoints: Dict[int, str],
        doc_type: str = "Investigation Report",
        max_feedback_items: int = 10
    ) -> str:
        """
        Build document analysis prompt following AWS Bedrock patterns

        AWS Pattern: Task-Context-Examples-Output

        Args:
            section_name: Section being analyzed
            content: Section content (token-limited)
            framework_checkpoints: Framework reference points
            doc_type: Document type
            max_feedback_items: Maximum feedback items to generate

        Returns:
            Optimized analysis prompt
        """

        # Convert framework to TOON format for token efficiency
        framework_toon = to_toon({'checkpoints': framework_checkpoints})

        prompt = f"""# Task: Analyze Document Section

## Context
Document Type: {doc_type}
Section: {section_name}
Framework: Hawkeye 20-Point Investigation Checklist

## Framework Reference (TOON Format for Efficiency)
{framework_toon}

## Section Content to Analyze
```
{content[:7500]}
```

## Analysis Instructions

Step 1: Read and Understand
- Read the section content carefully
- Identify the section's purpose and key elements
- Note any obvious gaps or issues

Step 2: Apply Framework
- Systematically evaluate against relevant Hawkeye checkpoints
- Focus on substantive quality issues
- Prioritize by impact and risk

Step 3: Generate Feedback
- Provide {max_feedback_items} high-quality feedback items maximum
- Each item must be specific and actionable
- Include clear evidence from the content
- Reference applicable Hawkeye checkpoints

Step 4: Assess Risk
- HIGH: Critical gaps, compliance issues, major risks
- MEDIUM: Significant improvements needed, moderate risks
- LOW: Minor enhancements, best practice suggestions

## Output Format (STRICT JSON)

Return ONLY valid JSON with this exact structure:

```json
{{
  "feedback_items": [
    {{
      "id": "FB001",
      "type": "critical|important|suggestion",
      "category": "Investigation Process|Documentation|Root Cause|Timeline|Risk Assessment|etc",
      "description": "Specific issue identified (1-2 sentences, 150 chars max)",
      "suggestion": "Actionable recommendation (1 sentence, 100 chars max)",
      "example": "Concrete example or reference (50 chars max)",
      "questions": ["Key question 1?", "Key question 2?"],
      "hawkeye_refs": [2, 11, 13],
      "risk_level": "High|Medium|Low",
      "confidence": 0.85
    }}
  ]
}}
```

## Critical Requirements

1. Return ONLY the JSON object (no markdown, no explanation)
2. All feedback items must have ALL fields
3. Description must be specific to this content
4. Suggestion must be actionable and clear
5. Hawkeye references must be relevant checkpoint numbers (1-20)
6. Confidence is float 0.0-1.0 based on evidence strength
7. Limit to {max_feedback_items} items maximum (only high-quality)
8. Filter by confidence >= 0.80 (only include high-confidence items)

## Example Output

```json
{{
  "feedback_items": [
    {{
      "id": "FB001",
      "type": "critical",
      "category": "Timeline",
      "description": "Timeline missing critical enforcement decision timestamps. Gaps >24hrs unexplained.",
      "suggestion": "Add DD-MMM-YYYY HH:MM format for all events. Explain delays >24hrs.",
      "example": "2024-Jan-15 14:30 - Seller notification sent",
      "questions": ["Who made enforcement decision?", "What caused the 48hr delay?"],
      "hawkeye_refs": [2, 13],
      "risk_level": "High",
      "confidence": 0.92
    }}
  ]
}}
```

Begin analysis now. Return only JSON."""

        return prompt

    # ========================================================================
    # CHAT ASSISTANT TEMPLATE (AWS Conversational Pattern)
    # ========================================================================

    @staticmethod
    def build_chat_prompt(
        user_query: str,
        context: Dict,
        framework_overview: str,
        conversation_history: Optional[List[Dict]] = None
    ) -> str:
        """
        Build chat prompt following AWS conversational patterns

        AWS Pattern: Context-History-Query-Constraints

        Args:
            user_query: User's question
            context: Current session context
            framework_overview: Framework overview
            conversation_history: Previous messages (optional)

        Returns:
            Optimized chat prompt
        """

        # Use TOON for context (token efficiency)
        context_toon = to_toon(context)

        prompt = f"""# Conversation Context

Current Session (TOON Format):
{context_toon}

Framework Overview:
{framework_overview}"""

        # Add conversation history if present
        if conversation_history and len(conversation_history) > 0:
            prompt += "\n\n## Recent Conversation\n"
            # Include last 3 exchanges for context
            recent = conversation_history[-6:]  # Last 3 user-assistant pairs
            for msg in recent:
                role = msg.get('role', 'user')
                content = msg.get('content', '')[:200]  # Truncate for token efficiency
                prompt += f"\n{role.upper()}: {content}"

        prompt += f"""

## User Question
{user_query}

## Response Guidelines

Provide a clear, helpful response that:
• Directly addresses the user's question
• References specific Hawkeye checkpoints when relevant
• Includes concrete examples or suggestions
• Maintains professional investigation perspective
• Is concise but comprehensive (2-3 paragraphs max)
• Uses bullet points for clarity when appropriate

Do NOT:
• Repeat the question
• Provide generic advice without specifics
• Reference information not in the framework
• Use overly technical jargon without explanation

Begin response now:"""

        return prompt

    # ========================================================================
    # SECTION IDENTIFICATION TEMPLATE (AWS Classification Pattern)
    # ========================================================================

    @staticmethod
    def build_section_identification_prompt(document_text: str) -> str:
        """
        Build section identification prompt following AWS classification patterns

        AWS Pattern: Task-Examples-Constraints-Output

        Args:
            document_text: Document text to analyze (truncated)

        Returns:
            Optimized section identification prompt
        """

        prompt = f"""# Task: Identify Document Sections

## Instructions
Analyze this business document and identify all main sections.

## Document Text (First 10,000 characters)
```
{document_text[:10000]}
```

## Section Identification Criteria

Look for:
1. Headers appearing on dedicated lines
2. Clear content transitions and topic changes
3. Standard business document sections
4. Numbered or bulleted section markers
5. Date-based or chronological divisions

Common Patterns:
• Executive Summary / Summary
• Background / Context
• Timeline of Events / Chronology
• Investigation Process / Methodology
• Findings / Results / Analysis
• Resolving Actions / Remediation
• Root Causes and Preventative Actions
• Impact Assessment
• Recommendations / Next Steps
• Conclusion

## Output Format (STRICT JSON)

Return ONLY valid JSON:

```json
{{
  "sections": [
    {{"title": "Executive Summary", "line_hint": "This investigation examined"}},
    {{"title": "Timeline", "line_hint": "January 15, 2024"}}
  ]
}}
```

## Requirements

1. Return ONLY the JSON object
2. Include ALL meaningful sections (minimum 2, maximum 12)
3. Use exact titles from document when clear
4. Line hints must be distinctive opening phrases
5. Maintain document order
6. Exclude headers, footers, email metadata

Begin analysis now. Return only JSON."""

        return prompt

    # ========================================================================
    # MULTI-TURN ANALYSIS TEMPLATE (AWS Sequential Pattern)
    # ========================================================================

    @staticmethod
    def build_followup_analysis_prompt(
        original_feedback: List[Dict],
        user_comment: str,
        section_content: str
    ) -> str:
        """
        Build follow-up analysis prompt for iterative refinement

        AWS Pattern: Previous-Context-New-Input-Output

        Args:
            original_feedback: Previous feedback items
            user_comment: User's comment or concern
            section_content: Section content (for reference)

        Returns:
            Optimized follow-up prompt
        """

        # Use TOON for original feedback (token efficiency)
        feedback_toon = to_toon({'previous_feedback': original_feedback})

        prompt = f"""# Task: Refine Analysis Based on User Input

## Previous Feedback (TOON Format)
{feedback_toon}

## User Comment
"{user_comment}"

## Section Content (Reference)
```
{section_content[:3000]}
```

## Instructions

Based on the user's comment:
1. Understand their specific concern or request
2. Review the previous feedback items
3. Provide refined or additional feedback that addresses their point
4. Maintain consistency with previous assessment

Output 1-3 refined feedback items in the same JSON format as before.

Begin analysis now. Return only JSON."""

        return prompt

    # ========================================================================
    # HELPER METHODS
    # ========================================================================

    @staticmethod
    def estimate_prompt_tokens(prompt: str) -> int:
        """
        Estimate token count for prompt
        Claude uses ~4 characters per token on average

        Args:
            prompt: Prompt text

        Returns:
            Estimated token count
        """
        return len(prompt) // 4 + 50  # Add buffer for formatting

    @staticmethod
    def truncate_content_for_tokens(content: str, max_tokens: int = 6000) -> str:
        """
        Truncate content to fit within token limit

        Args:
            content: Content to truncate
            max_tokens: Maximum tokens allowed

        Returns:
            Truncated content
        """
        max_chars = max_tokens * 4  # Approximate conversion
        if len(content) <= max_chars:
            return content

        # Truncate at sentence boundary if possible
        truncated = content[:max_chars]
        last_period = truncated.rfind('.')

        if last_period > max_chars * 0.8:  # Only if we're not losing too much
            return truncated[:last_period + 1]

        return truncated + "..."

    @staticmethod
    def format_framework_checkpoints(checkpoints: Dict[int, str], max_length: int = 500) -> str:
        """
        Format framework checkpoints for prompt inclusion

        Args:
            checkpoints: Dict of checkpoint number to description
            max_length: Maximum character length

        Returns:
            Formatted checkpoint list
        """
        lines = [f"{num}. {desc[:50]}" for num, desc in checkpoints.items()]
        formatted = "\n".join(lines)

        if len(formatted) > max_length:
            # Truncate to most relevant checkpoints
            relevant = lines[:10]
            formatted = "\n".join(relevant) + "\n... (additional checkpoints available)"

        return formatted
