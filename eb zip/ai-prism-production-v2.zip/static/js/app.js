// Main application JavaScript for AI-Prism Document Analysis Tool
console.log('AI-Prism app.js loaded successfully');

// This file serves as the main application entry point
// All button functionality is handled in button_fixes.js